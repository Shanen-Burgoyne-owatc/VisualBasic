﻿Public Class frmCurrency
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decUSD As Decimal
        Const decPounds As Decimal = 0.68D
        Const decEuro As Decimal = 0.83D
        Const decYen As Decimal = 108.36D

        Try
            ' Calculate USD to Pounds
            decUSD = CDec(txtUSD.Text) *
                decPounds
            lblPounds.Text = decUSD.ToString("N")

            ' Calculate USD to Euro
            decUSD = CDec(txtUSD.Text) *
                decEuro
            lblEuros.Text = decUSD.ToString("N")

            ' Calculate USD to Yen
            decUSD = CDec(txtUSD.Text) *
                decYen
            lblYen.Text = decUSD.ToString("N")
        Catch

        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear all the labels and text box in the Application
        lblEuros.Text = String.Empty
        lblPounds.Text = String.Empty
        lblYen.Text = String.Empty
        txtUSD.Clear()

        ' Set the focus back to txtUSD
        txtUSD.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
