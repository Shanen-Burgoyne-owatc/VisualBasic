﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        '  Delcare the variables 
        Dim decLandValue As Decimal
        Const decAssessmentTax As Decimal = 0.6D
        Dim decAssessmentValue As Decimal
        Dim decPropertyTax As Decimal

        Try
            decLandValue = CDec(txtLandValue.Text)

            decAssessmentValue = decLandValue * decAssessmentTax
            lblAssessmentValue.Text = decAssessmentValue.ToString("C")

            decPropertyTax = ((decAssessmentValue * 0.64D) / 100)
            lblPropertyTax.Text = decPropertyTax.ToString("C")
        Catch
            ' Error Message
            MessageBox.Show("Please Enter a Numerical Value")
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtLandValue.Clear()
        lblAssessmentValue.Text = String.Empty
        lblPropertyTax.Text = String.Empty

        txtLandValue.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
