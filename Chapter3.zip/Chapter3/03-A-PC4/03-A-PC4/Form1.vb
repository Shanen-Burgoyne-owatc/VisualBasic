﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decAdultPrice As Decimal
        Dim decAdultTickets As Decimal
        Dim decChildPrice As Decimal
        Dim decChildTickets As Decimal
        Dim decTotal As Decimal
        Dim decAdultTotal As Decimal
        Dim decChildTotal As Decimal
        Dim decAdultNet As Decimal
        Dim decChildNet As Decimal
        Dim decNet As Decimal
        Const decTax As Decimal = 0.2D

        Try
            ' Set the variables equal to their textboxes
            decAdultPrice = CDec(txtAdultPrice.Text)
            decAdultTickets = CDec(txtAdultTickets.Text)
            decChildPrice = CDec(txtChildPrice.Text)
            decChildTickets = CDec(txtChildTickets.Text)

            ' Calculate the totals of the ptices and tickets
            decAdultTotal = decAdultPrice * decAdultTickets
            lblAdult1.Text = decAdultTotal.ToString("C")

            decChildTotal = decChildPrice * decChildTickets
            lblChild1.Text = decChildTotal.ToString("C")

            decTotal = decAdultTotal + decChildTotal
            lblGross.Text = decTotal.ToString("C")

            decAdultNet = (decAdultTotal * decTax)
            lblAdult2.Text = decAdultNet.ToString("C")

            decChildNet = (decChildTotal * decTax)
            lblChild2.Text = decChildNet.ToString("C")

            decNet = (decAdultNet + decChildNet)
            lblNet.Text = decNet.ToString("C")
        Catch
            ' Error Message
            MessageBox.Show("Please Enter Numeric Values.")
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtAdultPrice.Clear()
        txtAdultTickets.Clear()
        txtChildPrice.Clear()
        txtChildTickets.Clear()
        lblAdult1.Text = String.Empty
        lblAdult2.Text = String.Empty
        lblChild1.Text = String.Empty
        lblChild2.Text = String.Empty
        lblGross.Text = String.Empty
        lblNet.Text = String.Empty

        txtAdultPrice.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
