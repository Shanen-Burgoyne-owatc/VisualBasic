﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intWeight As Integer
        Dim intHeight As Integer
        Dim dblBMI As Double

        Try
            intWeight = CInt(txtWeight.Text)
            intHeight = CInt(txtHeight.Text)

            dblBMI = ((intWeight * 703) / intHeight / intHeight)
            lblBMI.Text = dblBMI.ToString("F2")
        Catch

        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtHeight.Clear()
        txtWeight.Clear()
        lblBMI.Text = String.Empty

        txtHeight.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
