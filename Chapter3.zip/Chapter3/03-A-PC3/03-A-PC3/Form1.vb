﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Declare the variables for the test scores
        Dim intTest1 As Integer
        Dim intTest2 As Integer
        Dim intTest3 As Integer
        Dim intTest4 As Integer
        Dim intTest5 As Integer

        Try
            ' Pass the variable to the txtbox
            intTest1 = CInt(txtTest1.Text)
            intTest2 = CInt(txtTest2.Text)
            intTest3 = CInt(txtTest3.Text)
            intTest4 = CInt(txtTest4.Text)
            intTest5 = CInt(txtTest5.Text)

            lblAverage.Text = ((intTest1 + intTest2 + intTest3 + intTest4 + intTest5) / 5).ToString("N")
        Catch
            ' Error Message
            MessageBox.Show("Please enter numeric values only.")
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the Textboxes and set the focus to the first Test score textbox
        txtTest1.Clear()
        txtTest2.Clear()
        txtTest2.Clear()
        txtTest3.Clear()
        txtTest4.Clear()
        txtTest5.Clear()
        lblAverage.Text = String.Empty

        txtTest1.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
