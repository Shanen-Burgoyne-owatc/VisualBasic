﻿Public Class Form1
    Private Sub btnClaculate_Click(sender As Object, e As EventArgs) Handles btnClaculate.Click
        ' Delcare the variables used in the application
        Dim intClassA As Integer
        Dim intClassB As Integer
        Dim intClassC As Integer

        lblStatus.Text = String.Empty
        Try
            ' Calculate for Class A.
            intClassA = CInt(txtClassA.Text) * 15
            lblClassA.Text = intClassA.ToString("C")

            ' Calculate for Class B.
            intClassB = CInt(txtClassB.Text) * 12
            lblClassB.Text = intClassB.ToString("C")

            ' Calculate for Class C.
            intClassC = CInt(txtClassC.Text) * 9
            lblClassC.Text = intClassC.ToString("C")

            ' Calculate for Total Revenue
            lblTotal.Text = (intClassA + intClassB + intClassC).ToString("C")

        Catch
            ' Error Message
            MessageBox.Show("Please enter numeric values only.")
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clears the textboxes
        txtClassA.Clear()
        txtClassB.Clear()
        txtClassC.Clear()

        ' Clears the Labels
        lblClassA.Text = String.Empty
        lblClassB.Text = String.Empty
        lblClassC.Text = String.Empty
        lblStatus.Text = String.Empty
        lblTotal.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
