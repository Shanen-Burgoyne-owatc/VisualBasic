﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Declare Variables for the calculations
        Dim decGallons As Decimal
        Dim decMiles As Decimal
        Dim decMPG As Decimal
        lblStatus.Text = String.Empty

        Try
            ' Calculate and display the total Gallons the car can hold
            decGallons = CDec(txtGallons.Text)
            ' Calculate and display the total miles driven on a full tank
            decMiles = CDec(txtMiles.Text)

            ' Calculate the Total MPG
            decMPG = CDec(decMiles / decGallons)

            lblMPG.Text = decMPG.ToString("F2")
        Catch
            ' Display an error Message
            lblStatus.Text = "Error: sure to enter numeric values only"
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the form
        txtGallons.Clear()
        txtMiles.Clear()
        lblMPG.Text = String.Empty
        lblStatus.Text = String.Empty

        ' Reset the focus to txtGallons
        txtGallons.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Closes the form
        Me.Close()
    End Sub
End Class
