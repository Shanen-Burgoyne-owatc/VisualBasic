﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dblCookies As Double
        Dim dblCaloriePerCookie As Double
        Dim dblTotalCalories As Double

        Try
            dblCookies = CInt(txtNumberofCookies.Text)
            dblCaloriePerCookie = (300 / 4)

            dblTotalCalories = dblCaloriePerCookie * dblCookies
            lblTotalCalories.Text = dblTotalCalories.ToString()

        Catch
            MessageBox.Show("Please enter Numeric values only.")
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtNumberofCookies.Clear()
        lblTotalCalories.Text = String.Empty
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
