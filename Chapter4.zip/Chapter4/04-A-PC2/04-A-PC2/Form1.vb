﻿Public Class Form1
    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim intnumber As Integer = CInt(txt.Text)

        If intnumber >= 1 And intnumber <= 10 Then

            If intnumber = 1 Then
                lblRomanNum.Text = "I"
            End If

            If intnumber = 2 Then
                lblRomanNum.Text = "II"
            End If

            If intnumber = 3 Then
                lblRomanNum.Text = "III"
            End If

            If intnumber = 4 Then
                lblRomanNum.Text = "IV"
            End If

            If intnumber = 5 Then
                lblRomanNum.Text = "V"
            End If

            If intnumber = 6 Then
                lblRomanNum.Text = "VI"
            End If

            If intnumber = 7 Then
                lblRomanNum.Text = "VII"
            End If

            If intnumber = 8 Then
                lblRomanNum.Text = "VIII"
            End If

            If intnumber = 9 Then
                lblRomanNum.Text = "IX"
            End If

            If intnumber = 10 Then
                lblRomanNum.Text = "X"
            End If
        Else
            MessageBox.Show("Please enter a number between 1-10.")
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
