﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decBaseFee As Decimal
        Dim decTotalFee As Decimal
        Dim intMonths As Integer
        Dim blnInputOk As Boolean = True

        ' Constants for base fee
        Const decAdult_Fee As Decimal = 40D
        Const decChild_FEE As Decimal = 20D
        Const decStudent_FEE As Decimal = 25D
        Const decSenior_Fee As Decimal = 30D

        'Constant for additional fees
        Const decYoga_Fee As Decimal = 10D
        Const decKarate_fee As Decimal = 30D
        Const decTrainer_FEE As Decimal = 50D

        ' Validate and convert the number of motnhs.
        lblStatus.Text = String.Empty
        If Integer.TryParse(txtMonths.Text, intMonths) = False Then
            lblStatus.Text = "Months must be an integer."
            blnInputOk = False
        End If

        ' Validate the number of months
        If intMonths < 1 Or intMonths > 24 Then
            lblStatus.Text = "Months must be in the range 1-24."
            blnInputOk = False
        End If

        If blnInputOk = True Then
            ' Determine the base monthly fee.
            If radAdult.Checked = True Then
                decBaseFee = decAdult_Fee
            ElseIf radChild.Checked = True Then
                decBaseFee = decChild_FEE
            ElseIf radStudent.Checked = True Then
                decBaseFee = decStudent_FEE
            ElseIf radSenior.Checked = True Then
                decBaseFee = decSenior_Fee
            End If

            ' Check for additional services.
            If chkYoga.Checked = True Then
                decBaseFee += decYoga_Fee
            End If

            If chkKarate.Checked = True Then
                decBaseFee += decKarate_fee
            End If

            If chkTrainer.Checked = True Then
                decBaseFee += decTrainer_FEE
            End If

            ' Calculate the total fee.
            decTotalFee = decBaseFee * intMonths

            ' Display the fees.
            lblMonthlyFee.Text = decBaseFee.ToString("c")
            lblTotalFee.Text = decTotalFee.ToString("c")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Reset the Adult radio button.
        radAdult.Checked = True

        ' Clear the checkboxes.
        chkYoga.Checked = False
        chkKarate.Checked = False
        chkTrainer.Checked = False

        ' Clear the number of months.
        txtMonths.Clear()

        ' Clear the Fee lables
        lblMonthlyFee.Text = String.Empty
        lblTotalFee.Text = String.Empty
        lblStatus.Text = String.Empty

        ' Give txtmonths the focus
        txtMonths.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
