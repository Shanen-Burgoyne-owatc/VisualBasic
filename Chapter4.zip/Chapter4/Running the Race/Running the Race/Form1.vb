﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intTime1 As Integer
        Dim intTime2 As Integer
        Dim intTime3 As Integer

        intTime1 = CInt(txtFT1.Text)
        intTime2 = CInt(txtFT2.Text)
        intTime3 = CInt(txtFT3.Text)

        Dim runner1 As New runner
        runner1.time = CInt(txtFT1.Text)
        runner1.Name = txtRunner1.Text

        Dim runner2 As New runner
        runner2.time = CInt(txtFT2.Text)
        runner2.Name = txtRunner2.Text

        Dim runner3 As New runner
        runner3.time = CInt(txtFT3.Text)
        runner3.Name = txtRunner3.Text

        If runner1.time < runner2.time And runner1.time < runner3.time Then
            lbl1st.Text = runner1.Name
        End If

        If runner2.time < runner1.time And runner2.time < runner3.time Then
            lbl1st.Text = runner2.Name
        End If

        If runner3.time < runner2.time And runner3.time < runner1.time Then
            lbl1st.Text = runner3.Name
        End If

        If runner1.time > runner2.time And runner1.time < runner3.time Then
            lbl2nd.Text = runner1.Name
        End If

        If runner2.time > runner1.time And runner2.time < runner3.time Then
            lbl2nd.Text = runner2.Name
        End If

        If runner3.time > runner2.time And runner3.time < runner1.time Then
            lbl2nd.Text = runner3.Name
        End If

        If runner1.time > runner2.time And runner1.time > runner3.time Then
            lbl3rd.Text = runner1.Name
        End If

        If runner2.time > runner1.time And runner2.time > runner3.time Then
            lbl3rd.Text = runner2.Name
        End If

        If runner3.time > runner2.time And runner3.time > runner1.time Then
            lbl3rd.Text = runner3.Name
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtFT1.Clear()
        txtFT2.Clear()
        txtFT3.Clear()
        txtRunner1.Clear()
        txtRunner2.Clear()
        txtRunner3.Clear()
        lbl1st.Text = String.Empty
        lbl2nd.Text = String.Empty
        lbl3rd.Text = String.Empty

        txtRunner1.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class

Public Class runner
    Public time As Integer
    Public Name As String
End Class