﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intHours As Integer ' Number of hours
        Dim dectotalFee As Decimal ' Total Fee
        Dim decBaseFee As Decimal ' Base Monthly Fee

        Const decPackageA As Decimal = 9.95D
        Const decPackageB As Decimal = 14.95D
        Const decPackageC As Decimal = 19.95D
        Const decNonprofit As Decimal = 0.8D

        ' Validate the number of hours
        If Integer.TryParse(txtHours.Text, intHours) = False Then
            MessageBox.Show("Hours must be an integer")
        End If

        ' Validate the number of hours.
        If intHours < 1 Or intHours > 744 Then
            MessageBox.Show(" Months bust be between 1-744.")
        End If

        ' Determine the base monthly fee.
        If radPckA.Checked = True Then
            decBaseFee = decPackageA
            dectotalFee = decBaseFee + (intHours - 10) * 2
        ElseIf radPckB.Checked = True Then
            decBaseFee = decPackageB
            dectotalFee = decBaseFee + (intHours - 20)
        ElseIf radPckC.Checked = True Then
            decBaseFee = decPackageC
            dectotalFee = decPackageC
        End If

            ' Check for the Nonprofit Checkbox
            If chkNonProfit.Checked = True Then
                dectotalFee = decBaseFee * decNonprofit
            End If

            ' Display the fee
            lblTotalCharge.Text = dectotalFee.ToString("C")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtHours.Clear()

        radPckA.Checked = True

        chkNonProfit.Checked = False

        lblTotalCharge.Text = String.Empty

        txtHours.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
