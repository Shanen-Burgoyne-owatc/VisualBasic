﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkNonProfit = New System.Windows.Forms.CheckBox()
        Me.radPckC = New System.Windows.Forms.RadioButton()
        Me.radPckB = New System.Windows.Forms.RadioButton()
        Me.radPckA = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTotalCharge = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtHours = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkNonProfit)
        Me.GroupBox1.Controls.Add(Me.radPckC)
        Me.GroupBox1.Controls.Add(Me.radPckB)
        Me.GroupBox1.Controls.Add(Me.radPckA)
        Me.GroupBox1.Location = New System.Drawing.Point(101, 93)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 314)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Packages"
        '
        'chkNonProfit
        '
        Me.chkNonProfit.AutoSize = True
        Me.chkNonProfit.Location = New System.Drawing.Point(55, 218)
        Me.chkNonProfit.Name = "chkNonProfit"
        Me.chkNonProfit.Size = New System.Drawing.Size(180, 21)
        Me.chkNonProfit.TabIndex = 3
        Me.chkNonProfit.Text = "Nonprofit Organizations"
        Me.chkNonProfit.UseVisualStyleBackColor = True
        '
        'radPckC
        '
        Me.radPckC.AutoSize = True
        Me.radPckC.Location = New System.Drawing.Point(55, 168)
        Me.radPckC.Name = "radPckC"
        Me.radPckC.Size = New System.Drawing.Size(101, 21)
        Me.radPckC.TabIndex = 2
        Me.radPckC.TabStop = True
        Me.radPckC.Text = "Package C:"
        Me.radPckC.UseVisualStyleBackColor = True
        '
        'radPckB
        '
        Me.radPckB.AutoSize = True
        Me.radPckB.Location = New System.Drawing.Point(55, 108)
        Me.radPckB.Name = "radPckB"
        Me.radPckB.Size = New System.Drawing.Size(101, 21)
        Me.radPckB.TabIndex = 1
        Me.radPckB.TabStop = True
        Me.radPckB.Text = "Package B:"
        Me.radPckB.UseVisualStyleBackColor = True
        '
        'radPckA
        '
        Me.radPckA.AutoSize = True
        Me.radPckA.Checked = True
        Me.radPckA.Location = New System.Drawing.Point(55, 54)
        Me.radPckA.Name = "radPckA"
        Me.radPckA.Size = New System.Drawing.Size(101, 21)
        Me.radPckA.TabIndex = 0
        Me.radPckA.TabStop = True
        Me.radPckA.Text = "Package A:"
        Me.radPckA.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(36, 440)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(236, 29)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "The Monthly Charge:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalCharge
        '
        Me.lblTotalCharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCharge.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCharge.Location = New System.Drawing.Point(294, 440)
        Me.lblTotalCharge.Name = "lblTotalCharge"
        Me.lblTotalCharge.Size = New System.Drawing.Size(193, 29)
        Me.lblTotalCharge.TabIndex = 2
        Me.lblTotalCharge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(12, 506)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(149, 56)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(187, 506)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(149, 56)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(362, 506)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(149, 56)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(37, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(145, 24)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Hours of Usage:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtHours
        '
        Me.txtHours.Location = New System.Drawing.Point(188, 21)
        Me.txtHours.Multiline = True
        Me.txtHours.Name = "txtHours"
        Me.txtHours.Size = New System.Drawing.Size(129, 24)
        Me.txtHours.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(535, 598)
        Me.Controls.Add(Me.txtHours)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblTotalCharge)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Internet Service Provider"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkNonProfit As CheckBox
    Friend WithEvents radPckC As RadioButton
    Friend WithEvents radPckB As RadioButton
    Friend WithEvents radPckA As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTotalCharge As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents txtHours As TextBox
End Class
