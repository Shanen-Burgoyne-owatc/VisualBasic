﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intNOC As Integer

        intNOC = CInt(txtNOC.Text)

        If intNOC > 1 And intNOC <= 19 Then
            Dim decNum = 0.1
            lblMonthlyFee.Text = ((decNum * CDec(intNOC)) + 10).ToString("C")
        End If

        If intNOC >= 20 And intNOC <= 39 Then
            Dim decNum = 0.08
            lblMonthlyFee.Text = ((decNum * CDec(intNOC)) + 10).ToString("C")
        End If

        If intNOC >= 40 And intNOC <= 59 Then
            Dim decNum = 0.06
            lblMonthlyFee.Text = ((decNum * CDec(intNOC)) + 10).ToString("C")
        End If

        If intNOC >= 60 Then
            Dim decNum = 0.04
            lblMonthlyFee.Text = ((decNum * CDec(intNOC)) + 10).ToString("C")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtNOC.Clear()
        lblMonthlyFee.Text = String.Empty

        txtNOC.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
