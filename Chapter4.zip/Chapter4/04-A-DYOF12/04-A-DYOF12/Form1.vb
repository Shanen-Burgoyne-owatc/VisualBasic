﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intHours As Integer ' Number of hours
        Dim dectotalFeeA As Decimal ' Total Fee
        Dim dectotalFeeB As Decimal
        Dim dectotalFeeC As Decimal
        Dim decSavingsA As Decimal
        Dim decSavingsB As Decimal
        Dim decSavingsC As Decimal
        Dim decBaseFee As Decimal ' Base Monthly Fee

        Const decPackageA As Decimal = 9.95D
        Const decPackageB As Decimal = 14.95D
        Const decPackageC As Decimal = 19.95D
        Const decNonprofit As Decimal = 0.8D

        ' Validate the number of hours
        If Integer.TryParse(txtHours.Text, intHours) = False Then
            MessageBox.Show("Hours must be an integer")
        End If

        ' Validate the number of hours.
        If intHours < 1 Or intHours > 744 Then
            MessageBox.Show(" Months bust be between 1-744.")
        End If

        ' Determine the base monthly fee.
        If radPckA.Checked = True Then
            decBaseFee = decPackageA
            If intHours < 10 Then
                dectotalFeeA = 9.95D
            Else
                dectotalFeeA = decBaseFee + ((intHours - 10) * 2)
            End If
            lblTotalCharge.Text = dectotalFeeA.ToString("C")
        ElseIf radPckB.Checked = True Then
            decBaseFee = decPackageB
            If intHours < 20 Then
                dectotalFeeB = 14.95D
            Else
                dectotalFeeB = decBaseFee + (intHours - 20)
            End If
            lblTotalCharge.Text = dectotalFeeB.ToString("C")
        ElseIf radPckC.Checked = True Then
            decBaseFee = decPackageC
            dectotalFeeC = decPackageC
            lblTotalCharge.Text = dectotalFeeC.ToString("C")
        End If

        'decSavingsB = dectotalFeeA - dectotalFeeB
        'decSavingsC = dectotalFeeA - dectotalFeeC
        If chkDisplaySavings.Checked = True Then
            decBaseFee = decPackageA
            If intHours < 10 Then
                intHours = 10
            End If
            dectotalFeeA = decBaseFee + ((intHours - 10) * 2)
            decBaseFee = decPackageB
            If intHours < 20 Then
                intHours = 20
            End If
            dectotalFeeB = decBaseFee + (intHours - 20)
            decBaseFee = decPackageC
            dectotalFeeC = decPackageC
            If radPckA.Checked = True And dectotalFeeA <= dectotalFeeB And dectotalFeeA <= dectotalFeeC Then
                lblPotenialSavings.Text = "No savings with Packages B or C"
            ElseIf radPckA.Checked = True And dectotalFeeA > dectotalFeeB And dectotalFeeA > dectotalFeeC Then
                lblPotenialSavings.Text = "Package B and Package C has better savings"
            ElseIf radPckB.Checked = True And dectotalFeeB <= dectotalFeeC Then
                lblPotenialSavings.Text = "No savings with Package C"
            ElseIf radPckB.checked = True And dectotalFeeB > dectotalFeeC Then
                lblPotenialSavings.Text = "Package C has better savings"

            End If
        End If



        ' Check for the Nonprofit Checkbox
        If chkNonProfit.Checked = True Then
            dectotalFeeA = decBaseFee * decNonprofit
        End If

        If chkNonProfit.Checked = True Then
            dectotalFeeB = decBaseFee * decNonprofit
        End If

        If chkNonProfit.Checked = True Then
            dectotalFeeC = decBaseFee * decNonprofit
        End If

        ' Display the fee



    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtHours.Clear()

        radPckA.Checked = True

        chkNonProfit.Checked = False

        lblTotalCharge.Text = String.Empty
        lblPotenialSavings.Text = String.Empty

        txtHours.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
