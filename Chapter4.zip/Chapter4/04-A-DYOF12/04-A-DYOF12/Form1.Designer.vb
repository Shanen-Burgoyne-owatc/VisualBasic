﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtHours = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblTotalCharge = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkDisplaySavings = New System.Windows.Forms.CheckBox()
        Me.chkNonProfit = New System.Windows.Forms.CheckBox()
        Me.radPckC = New System.Windows.Forms.RadioButton()
        Me.radPckB = New System.Windows.Forms.RadioButton()
        Me.radPckA = New System.Windows.Forms.RadioButton()
        Me.lblPotenialSavings = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtHours
        '
        Me.txtHours.Location = New System.Drawing.Point(205, 25)
        Me.txtHours.Multiline = True
        Me.txtHours.Name = "txtHours"
        Me.txtHours.Size = New System.Drawing.Size(129, 24)
        Me.txtHours.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(54, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 24)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Hours of Usage:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(379, 556)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(149, 56)
        Me.btnExit.TabIndex = 13
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(205, 556)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(149, 56)
        Me.btnClear.TabIndex = 12
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(27, 556)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(149, 56)
        Me.btnCalculate.TabIndex = 11
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lblTotalCharge
        '
        Me.lblTotalCharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCharge.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCharge.Location = New System.Drawing.Point(310, 372)
        Me.lblTotalCharge.Name = "lblTotalCharge"
        Me.lblTotalCharge.Size = New System.Drawing.Size(193, 29)
        Me.lblTotalCharge.TabIndex = 10
        Me.lblTotalCharge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(53, 372)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(236, 29)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "The Monthly Charge:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkDisplaySavings)
        Me.GroupBox1.Controls.Add(Me.chkNonProfit)
        Me.GroupBox1.Controls.Add(Me.radPckC)
        Me.GroupBox1.Controls.Add(Me.radPckB)
        Me.GroupBox1.Controls.Add(Me.radPckA)
        Me.GroupBox1.Location = New System.Drawing.Point(115, 55)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 314)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Packages"
        '
        'chkDisplaySavings
        '
        Me.chkDisplaySavings.AutoSize = True
        Me.chkDisplaySavings.Location = New System.Drawing.Point(53, 264)
        Me.chkDisplaySavings.Name = "chkDisplaySavings"
        Me.chkDisplaySavings.Size = New System.Drawing.Size(189, 21)
        Me.chkDisplaySavings.TabIndex = 4
        Me.chkDisplaySavings.Text = "Display Potential Savings"
        Me.chkDisplaySavings.UseVisualStyleBackColor = True
        '
        'chkNonProfit
        '
        Me.chkNonProfit.AutoSize = True
        Me.chkNonProfit.Location = New System.Drawing.Point(55, 218)
        Me.chkNonProfit.Name = "chkNonProfit"
        Me.chkNonProfit.Size = New System.Drawing.Size(180, 21)
        Me.chkNonProfit.TabIndex = 3
        Me.chkNonProfit.Text = "Nonprofit Organizations"
        Me.chkNonProfit.UseVisualStyleBackColor = True
        '
        'radPckC
        '
        Me.radPckC.AutoSize = True
        Me.radPckC.Location = New System.Drawing.Point(55, 168)
        Me.radPckC.Name = "radPckC"
        Me.radPckC.Size = New System.Drawing.Size(101, 21)
        Me.radPckC.TabIndex = 2
        Me.radPckC.TabStop = True
        Me.radPckC.Text = "Package C:"
        Me.radPckC.UseVisualStyleBackColor = True
        '
        'radPckB
        '
        Me.radPckB.AutoSize = True
        Me.radPckB.Location = New System.Drawing.Point(55, 108)
        Me.radPckB.Name = "radPckB"
        Me.radPckB.Size = New System.Drawing.Size(101, 21)
        Me.radPckB.TabIndex = 1
        Me.radPckB.TabStop = True
        Me.radPckB.Text = "Package B:"
        Me.radPckB.UseVisualStyleBackColor = True
        '
        'radPckA
        '
        Me.radPckA.AutoSize = True
        Me.radPckA.Checked = True
        Me.radPckA.Location = New System.Drawing.Point(55, 54)
        Me.radPckA.Name = "radPckA"
        Me.radPckA.Size = New System.Drawing.Size(101, 21)
        Me.radPckA.TabIndex = 0
        Me.radPckA.TabStop = True
        Me.radPckA.Text = "Package A:"
        Me.radPckA.UseVisualStyleBackColor = True
        '
        'lblPotenialSavings
        '
        Me.lblPotenialSavings.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPotenialSavings.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPotenialSavings.Location = New System.Drawing.Point(115, 443)
        Me.lblPotenialSavings.Name = "lblPotenialSavings"
        Me.lblPotenialSavings.Size = New System.Drawing.Size(336, 98)
        Me.lblPotenialSavings.TabIndex = 16
        Me.lblPotenialSavings.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(147, 414)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(261, 29)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Your Potential Savings:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(556, 624)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblPotenialSavings)
        Me.Controls.Add(Me.txtHours)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblTotalCharge)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtHours As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblTotalCharge As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkDisplaySavings As CheckBox
    Friend WithEvents chkNonProfit As CheckBox
    Friend WithEvents radPckC As RadioButton
    Friend WithEvents radPckB As RadioButton
    Friend WithEvents radPckA As RadioButton
    Friend WithEvents lblPotenialSavings As Label
    Friend WithEvents Label2 As Label
End Class
