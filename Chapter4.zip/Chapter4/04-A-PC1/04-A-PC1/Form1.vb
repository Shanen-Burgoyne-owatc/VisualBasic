﻿Public Class Form1
    Private Sub btnCompare_Click(sender As Object, e As EventArgs) Handles btnCompare.Click
        Dim intNumber1 As Integer
        Dim intNumber2 As Integer

        If Integer.TryParse(txtA.Text, intNumber1) And Integer.TryParse(txtB.Text, intNumber2) Then
            If intNumber1 > intNumber2 Then
                lblResult.Text = "A is greater."
            End If
            If intNumber2 > intNumber1 Then
                lblResult.Text = "B is greater."
            End If
            If intNumber1 = intNumber2 Then
                lblResult.Text = "Both numbers are equal."
            End If
        Else
            MessageBox.Show("Please enter numeric Values only.")
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
