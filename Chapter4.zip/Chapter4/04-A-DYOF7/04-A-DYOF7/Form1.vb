﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decWeight As Decimal
        Dim intMiles As Integer


        decWeight = CDec(txtWeight.Text)
        intMiles = CInt(txtShipping.Text)
        If intMiles < 10 Or intMiles > 3000 Then
            Return
        End If

        If decWeight <= 2 Then
            Dim decRPM = 0.01D
            lblShippingCost.Text = (intMiles * decRPM).ToString("C")
        End If

        If decWeight > 2 And decWeight <= 6 Then
            Dim decRPM = 0.015D
            lblShippingCost.Text = (intMiles * decRPM).ToString("C")
        End If
        If decWeight > 6 And decWeight <= 10 Then
            Dim decRPM = 0.02D
            lblShippingCost.Text = (intMiles * decRPM).ToString("C")
        End If

        If decWeight > 10 And decWeight <= 20 Then
            Dim decRPM = 0.025D
            lblShippingCost.Text = (intMiles * decRPM).ToString("C")
        Else
            MessageBox.Show("Can't be greater than 20")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtShipping.Clear()
        txtWeight.Clear()
        lblShippingCost.Text = String.Empty

        txtWeight.Focus()
    End Sub

    Private Sub brnExit_Click(sender As Object, e As EventArgs) Handles brnExit.Click
        Me.Close()
    End Sub
End Class
