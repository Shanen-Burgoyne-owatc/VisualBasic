﻿Imports System.IO
Public Class Form1
    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        Dim randomnumber As Random
        Dim number As Integer

        randomnumber = New Random

        number = randomnumber.Next(1, 1001)

        Dim txtFile As StreamWriter

        txtFile = File.CreateText(txtFileName.Text)

        Dim rand As New Random

        For intCount = 1 To 100
            number = rand.Next(1, 1000)
            txtFile.WriteLine(number)
        Next

        txtFile.Close()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
