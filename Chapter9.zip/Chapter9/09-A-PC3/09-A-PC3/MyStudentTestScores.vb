﻿Imports System.IO
Imports System.IO.FileStream
Public Class MyStudentTestScores
    Dim s(6) As MyStudent
    Public Function IsValid(ByVal score As Integer) As Integer
        If score >= 0 And score <= 100 Then
            Return (score)
        Else
            Return MessageBox.Show("Please try again!")
        End If
    End Function
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        For inc1 = 0 To 5
            s(inc1) = New MyStudent()
            ReDim s(inc1).tScores(4)
        Next
        Try
            ' Student One's Scores
            s(0).sName = txtName1.Text
            s(0).tScores(0) = IsValid(Convert.ToInt32(txt1.Text))
            s(0).tScores(1) = IsValid(Convert.ToInt32(txt2.Text))
            s(0).tScores(2) = IsValid(Convert.ToInt32(txt3.Text))
            s(0).tScores(3) = IsValid(Convert.ToInt32(txt4.Text))
            s(0).tScores(4) = IsValid(Convert.ToInt32(txt5.Text))

            ' Student Two's Scores
            s(1).sName = txtName2.Text
            s(1).tScores(0) = IsValid(Convert.ToInt32(txt6.Text))
            s(1).tScores(1) = IsValid(Convert.ToInt32(txt7.Text))
            s(1).tScores(2) = IsValid(Convert.ToInt32(txt8.Text))
            s(1).tScores(3) = IsValid(Convert.ToInt32(txt9.Text))
            s(1).tScores(4) = IsValid(Convert.ToInt32(txt10.Text))

            ' Student Three's Scores
            s(2).sName = txtName3.Text
            s(2).tScores(0) = IsValid(Convert.ToInt32(txt11.Text))
            s(2).tScores(1) = IsValid(Convert.ToInt32(txt12.Text))
            s(2).tScores(2) = IsValid(Convert.ToInt32(txt13.Text))
            s(2).tScores(3) = IsValid(Convert.ToInt32(txt14.Text))
            s(2).tScores(4) = IsValid(Convert.ToInt32(txt15.Text))

            ' Student Four's Scores
            s(3).sName = txtName4.Text
            s(3).tScores(0) = IsValid(Convert.ToInt32(txt16.Text))
            s(3).tScores(1) = IsValid(Convert.ToInt32(txt17.Text))
            s(3).tScores(2) = IsValid(Convert.ToInt32(txt18.Text))
            s(3).tScores(3) = IsValid(Convert.ToInt32(txt19.Text))
            s(3).tScores(4) = IsValid(Convert.ToInt32(txt20.Text))

            ' Student Five's Scores
            s(4).sName = txtName5.Text
            s(4).tScores(0) = IsValid(Convert.ToInt32(txt21.Text))
            s(4).tScores(1) = IsValid(Convert.ToInt32(txt22.Text))
            s(4).tScores(2) = IsValid(Convert.ToInt32(txt23.Text))
            s(4).tScores(3) = IsValid(Convert.ToInt32(txt24.Text))
            s(4).tScores(4) = IsValid(Convert.ToInt32(txt25.Text))

            'Student Six's Scores
            s(5).sName = txtName6.Text
            s(5).tScores(0) = IsValid(Convert.ToInt32(txt26.Text))
            s(5).tScores(1) = IsValid(Convert.ToInt32(txt27.Text))
            s(5).tScores(2) = IsValid(Convert.ToInt32(txt28.Text))
            s(5).tScores(3) = IsValid(Convert.ToInt32(txt29.Text))
            s(5).tScores(4) = IsValid(Convert.ToInt32(txt30.Text))
        Catch ex As Exception
            MessageBox.Show("Enter a Value within 0-100!")
        End Try

        For inc1 = 0 To 5
            s(inc1).sAverage = 0
            For inc2 = 0 To 4
                s(inc1).sAverage += s(inc1).tScores(inc2)
            Next
            s(inc1).sAverage /= 5
        Next

        lblAVG1.Text = s(0).sAverage.ToString("n2")
        lblAVG2.Text = s(1).sAverage.ToString("n2")
        lblAVG3.Text = s(2).sAverage.ToString("n2")
        lblAVG4.Text = s(3).sAverage.ToString("n2")
        lblAVG5.Text = s(4).sAverage.ToString("n2")
        lblAVG6.Text = s(5).sAverage.ToString("n2")

        For inc1 = 0 To 5
            Dim stdRecord As String
            stdRecord = s(inc1).sName
            For inc2 = 0 To 4
                stdRecord += "" +
                    s(inc1).tScores(inc2).ToString("n2")
            Next
            ' FIX ME IF I DON'T WORK!!!!!
            stdRecord += "" & (inc1).ToString()
        Next
    End Sub

    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click
        Dim nameOfFile As String = InputBox("Enter filename: ", "Filename prompt",
                                            "TestScores.txt")
        Dim saveFile As IO.StreamWriter = IO.File.CreateText(nameOfFile)

        For i = 0 To 5
            saveFile.WriteLine(s(i).sName)
            saveFile.WriteLine(s(i).tScores(0))
            saveFile.WriteLine(s(i).tScores(1))
            saveFile.WriteLine(s(i).tScores(2))
            saveFile.WriteLine(s(i).tScores(3))
            saveFile.WriteLine(s(i).tScores(4))

            saveFile.WriteLine(s(i).sAverage)
        Next
        saveFile.Close()


        MessageBox.Show(nameOfFile & "file successfully created!", "DONE")
    End Sub

    Private Sub mnuReport_Click(sender As Object, e As EventArgs) Handles mnuReport.Click
        Dim reportString As String = ""

        For i = 0 To 5
            reportString &= s(i).sName & vbTab

            reportString &= s(i).tScores(0) & vbTab
            reportString &= s(i).tScores(1) & vbTab
            reportString &= s(i).tScores(2) & vbTab
            reportString &= s(i).tScores(3) & vbTab
            reportString &= s(i).tScores(4) & vbTab

            reportString &= s(i).sAverage & vbNewLine
        Next

        MessageBox.Show(reportString, "Report")
    End Sub

    Private Sub mnuHelp_Click(sender As Object, e As EventArgs) Handles mnuHelp.Click
        MessageBox.Show(vbTab + vbTab + vbTab + "Student Test Scores" + vbNewLine + vbNewLine +
                        "This is a Project to compute Averages for the Students' test scores,
                        Save the Scores and Average in a file specified and generate a report
                        of the Students' Scores and Average")
    End Sub
End Class
Public Class MyStudent
    Public Property sName() As String
    Public tScores() As Integer
    Public Property sAverage() As Decimal
End Class
