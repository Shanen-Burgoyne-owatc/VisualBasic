﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MyStudentTestScores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblAVG6 = New System.Windows.Forms.Label()
        Me.txt30 = New System.Windows.Forms.TextBox()
        Me.txt29 = New System.Windows.Forms.TextBox()
        Me.txt28 = New System.Windows.Forms.TextBox()
        Me.txt27 = New System.Windows.Forms.TextBox()
        Me.txt26 = New System.Windows.Forms.TextBox()
        Me.txtName6 = New System.Windows.Forms.TextBox()
        Me.lblAVG5 = New System.Windows.Forms.Label()
        Me.lblAVG4 = New System.Windows.Forms.Label()
        Me.lblAVG3 = New System.Windows.Forms.Label()
        Me.lblAVG2 = New System.Windows.Forms.Label()
        Me.lblAVG1 = New System.Windows.Forms.Label()
        Me.txt25 = New System.Windows.Forms.TextBox()
        Me.txt24 = New System.Windows.Forms.TextBox()
        Me.txt23 = New System.Windows.Forms.TextBox()
        Me.txt22 = New System.Windows.Forms.TextBox()
        Me.txt21 = New System.Windows.Forms.TextBox()
        Me.txt20 = New System.Windows.Forms.TextBox()
        Me.txt19 = New System.Windows.Forms.TextBox()
        Me.txt18 = New System.Windows.Forms.TextBox()
        Me.txt17 = New System.Windows.Forms.TextBox()
        Me.txt16 = New System.Windows.Forms.TextBox()
        Me.txt15 = New System.Windows.Forms.TextBox()
        Me.txt14 = New System.Windows.Forms.TextBox()
        Me.txt13 = New System.Windows.Forms.TextBox()
        Me.txt12 = New System.Windows.Forms.TextBox()
        Me.txt11 = New System.Windows.Forms.TextBox()
        Me.txt10 = New System.Windows.Forms.TextBox()
        Me.txt9 = New System.Windows.Forms.TextBox()
        Me.txt8 = New System.Windows.Forms.TextBox()
        Me.txt7 = New System.Windows.Forms.TextBox()
        Me.txt6 = New System.Windows.Forms.TextBox()
        Me.txt5 = New System.Windows.Forms.TextBox()
        Me.txt4 = New System.Windows.Forms.TextBox()
        Me.txt3 = New System.Windows.Forms.TextBox()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.txtName5 = New System.Windows.Forms.TextBox()
        Me.txtName4 = New System.Windows.Forms.TextBox()
        Me.txtName3 = New System.Windows.Forms.TextBox()
        Me.txtName2 = New System.Windows.Forms.TextBox()
        Me.txtName1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuReport, Me.mnuHelp})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(909, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileSave})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(44, 24)
        Me.mnuFile.Text = "&File"
        '
        'mnuFileSave
        '
        Me.mnuFileSave.Name = "mnuFileSave"
        Me.mnuFileSave.Size = New System.Drawing.Size(115, 26)
        Me.mnuFileSave.Text = "&Save"
        '
        'mnuReport
        '
        Me.mnuReport.Name = "mnuReport"
        Me.mnuReport.Size = New System.Drawing.Size(66, 24)
        Me.mnuReport.Text = "&Report"
        '
        'mnuHelp
        '
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(53, 24)
        Me.mnuHelp.Text = "&Help"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblAVG6)
        Me.GroupBox1.Controls.Add(Me.txt30)
        Me.GroupBox1.Controls.Add(Me.txt29)
        Me.GroupBox1.Controls.Add(Me.txt28)
        Me.GroupBox1.Controls.Add(Me.txt27)
        Me.GroupBox1.Controls.Add(Me.txt26)
        Me.GroupBox1.Controls.Add(Me.txtName6)
        Me.GroupBox1.Controls.Add(Me.lblAVG5)
        Me.GroupBox1.Controls.Add(Me.lblAVG4)
        Me.GroupBox1.Controls.Add(Me.lblAVG3)
        Me.GroupBox1.Controls.Add(Me.lblAVG2)
        Me.GroupBox1.Controls.Add(Me.lblAVG1)
        Me.GroupBox1.Controls.Add(Me.txt25)
        Me.GroupBox1.Controls.Add(Me.txt24)
        Me.GroupBox1.Controls.Add(Me.txt23)
        Me.GroupBox1.Controls.Add(Me.txt22)
        Me.GroupBox1.Controls.Add(Me.txt21)
        Me.GroupBox1.Controls.Add(Me.txt20)
        Me.GroupBox1.Controls.Add(Me.txt19)
        Me.GroupBox1.Controls.Add(Me.txt18)
        Me.GroupBox1.Controls.Add(Me.txt17)
        Me.GroupBox1.Controls.Add(Me.txt16)
        Me.GroupBox1.Controls.Add(Me.txt15)
        Me.GroupBox1.Controls.Add(Me.txt14)
        Me.GroupBox1.Controls.Add(Me.txt13)
        Me.GroupBox1.Controls.Add(Me.txt12)
        Me.GroupBox1.Controls.Add(Me.txt11)
        Me.GroupBox1.Controls.Add(Me.txt10)
        Me.GroupBox1.Controls.Add(Me.txt9)
        Me.GroupBox1.Controls.Add(Me.txt8)
        Me.GroupBox1.Controls.Add(Me.txt7)
        Me.GroupBox1.Controls.Add(Me.txt6)
        Me.GroupBox1.Controls.Add(Me.txt5)
        Me.GroupBox1.Controls.Add(Me.txt4)
        Me.GroupBox1.Controls.Add(Me.txt3)
        Me.GroupBox1.Controls.Add(Me.txt2)
        Me.GroupBox1.Controls.Add(Me.txt1)
        Me.GroupBox1.Controls.Add(Me.txtName5)
        Me.GroupBox1.Controls.Add(Me.txtName4)
        Me.GroupBox1.Controls.Add(Me.txtName3)
        Me.GroupBox1.Controls.Add(Me.txtName2)
        Me.GroupBox1.Controls.Add(Me.txtName1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(45, 49)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(843, 371)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Student Data"
        '
        'lblAVG6
        '
        Me.lblAVG6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAVG6.Location = New System.Drawing.Point(735, 320)
        Me.lblAVG6.Name = "lblAVG6"
        Me.lblAVG6.Size = New System.Drawing.Size(58, 29)
        Me.lblAVG6.TabIndex = 44
        '
        'txt30
        '
        Me.txt30.Location = New System.Drawing.Point(626, 318)
        Me.txt30.Multiline = True
        Me.txt30.Name = "txt30"
        Me.txt30.Size = New System.Drawing.Size(58, 29)
        Me.txt30.TabIndex = 43
        '
        'txt29
        '
        Me.txt29.Location = New System.Drawing.Point(538, 318)
        Me.txt29.Multiline = True
        Me.txt29.Name = "txt29"
        Me.txt29.Size = New System.Drawing.Size(58, 29)
        Me.txt29.TabIndex = 42
        '
        'txt28
        '
        Me.txt28.Location = New System.Drawing.Point(448, 318)
        Me.txt28.Multiline = True
        Me.txt28.Name = "txt28"
        Me.txt28.Size = New System.Drawing.Size(58, 29)
        Me.txt28.TabIndex = 41
        '
        'txt27
        '
        Me.txt27.Location = New System.Drawing.Point(355, 318)
        Me.txt27.Multiline = True
        Me.txt27.Name = "txt27"
        Me.txt27.Size = New System.Drawing.Size(58, 29)
        Me.txt27.TabIndex = 40
        '
        'txt26
        '
        Me.txt26.Location = New System.Drawing.Point(262, 318)
        Me.txt26.Multiline = True
        Me.txt26.Name = "txt26"
        Me.txt26.Size = New System.Drawing.Size(58, 29)
        Me.txt26.TabIndex = 39
        '
        'txtName6
        '
        Me.txtName6.Location = New System.Drawing.Point(40, 318)
        Me.txtName6.Multiline = True
        Me.txtName6.Name = "txtName6"
        Me.txtName6.Size = New System.Drawing.Size(173, 29)
        Me.txtName6.TabIndex = 38
        '
        'lblAVG5
        '
        Me.lblAVG5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAVG5.Location = New System.Drawing.Point(735, 269)
        Me.lblAVG5.Name = "lblAVG5"
        Me.lblAVG5.Size = New System.Drawing.Size(58, 29)
        Me.lblAVG5.TabIndex = 37
        '
        'lblAVG4
        '
        Me.lblAVG4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAVG4.Location = New System.Drawing.Point(735, 223)
        Me.lblAVG4.Name = "lblAVG4"
        Me.lblAVG4.Size = New System.Drawing.Size(58, 29)
        Me.lblAVG4.TabIndex = 36
        '
        'lblAVG3
        '
        Me.lblAVG3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAVG3.Location = New System.Drawing.Point(735, 179)
        Me.lblAVG3.Name = "lblAVG3"
        Me.lblAVG3.Size = New System.Drawing.Size(58, 29)
        Me.lblAVG3.TabIndex = 35
        '
        'lblAVG2
        '
        Me.lblAVG2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAVG2.Location = New System.Drawing.Point(735, 133)
        Me.lblAVG2.Name = "lblAVG2"
        Me.lblAVG2.Size = New System.Drawing.Size(58, 29)
        Me.lblAVG2.TabIndex = 34
        '
        'lblAVG1
        '
        Me.lblAVG1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAVG1.Location = New System.Drawing.Point(735, 87)
        Me.lblAVG1.Name = "lblAVG1"
        Me.lblAVG1.Size = New System.Drawing.Size(58, 29)
        Me.lblAVG1.TabIndex = 33
        '
        'txt25
        '
        Me.txt25.Location = New System.Drawing.Point(626, 267)
        Me.txt25.Multiline = True
        Me.txt25.Name = "txt25"
        Me.txt25.Size = New System.Drawing.Size(58, 29)
        Me.txt25.TabIndex = 32
        '
        'txt24
        '
        Me.txt24.Location = New System.Drawing.Point(538, 267)
        Me.txt24.Multiline = True
        Me.txt24.Name = "txt24"
        Me.txt24.Size = New System.Drawing.Size(58, 29)
        Me.txt24.TabIndex = 31
        '
        'txt23
        '
        Me.txt23.Location = New System.Drawing.Point(448, 267)
        Me.txt23.Multiline = True
        Me.txt23.Name = "txt23"
        Me.txt23.Size = New System.Drawing.Size(58, 29)
        Me.txt23.TabIndex = 30
        '
        'txt22
        '
        Me.txt22.Location = New System.Drawing.Point(355, 267)
        Me.txt22.Multiline = True
        Me.txt22.Name = "txt22"
        Me.txt22.Size = New System.Drawing.Size(58, 29)
        Me.txt22.TabIndex = 29
        '
        'txt21
        '
        Me.txt21.Location = New System.Drawing.Point(262, 267)
        Me.txt21.Multiline = True
        Me.txt21.Name = "txt21"
        Me.txt21.Size = New System.Drawing.Size(58, 29)
        Me.txt21.TabIndex = 28
        '
        'txt20
        '
        Me.txt20.Location = New System.Drawing.Point(626, 221)
        Me.txt20.Multiline = True
        Me.txt20.Name = "txt20"
        Me.txt20.Size = New System.Drawing.Size(58, 29)
        Me.txt20.TabIndex = 27
        '
        'txt19
        '
        Me.txt19.Location = New System.Drawing.Point(538, 221)
        Me.txt19.Multiline = True
        Me.txt19.Name = "txt19"
        Me.txt19.Size = New System.Drawing.Size(58, 29)
        Me.txt19.TabIndex = 26
        '
        'txt18
        '
        Me.txt18.Location = New System.Drawing.Point(448, 221)
        Me.txt18.Multiline = True
        Me.txt18.Name = "txt18"
        Me.txt18.Size = New System.Drawing.Size(58, 29)
        Me.txt18.TabIndex = 25
        '
        'txt17
        '
        Me.txt17.Location = New System.Drawing.Point(355, 221)
        Me.txt17.Multiline = True
        Me.txt17.Name = "txt17"
        Me.txt17.Size = New System.Drawing.Size(58, 29)
        Me.txt17.TabIndex = 24
        '
        'txt16
        '
        Me.txt16.Location = New System.Drawing.Point(262, 221)
        Me.txt16.Multiline = True
        Me.txt16.Name = "txt16"
        Me.txt16.Size = New System.Drawing.Size(58, 29)
        Me.txt16.TabIndex = 23
        '
        'txt15
        '
        Me.txt15.Location = New System.Drawing.Point(626, 177)
        Me.txt15.Multiline = True
        Me.txt15.Name = "txt15"
        Me.txt15.Size = New System.Drawing.Size(58, 29)
        Me.txt15.TabIndex = 22
        '
        'txt14
        '
        Me.txt14.Location = New System.Drawing.Point(538, 177)
        Me.txt14.Multiline = True
        Me.txt14.Name = "txt14"
        Me.txt14.Size = New System.Drawing.Size(58, 29)
        Me.txt14.TabIndex = 21
        '
        'txt13
        '
        Me.txt13.Location = New System.Drawing.Point(448, 177)
        Me.txt13.Multiline = True
        Me.txt13.Name = "txt13"
        Me.txt13.Size = New System.Drawing.Size(58, 29)
        Me.txt13.TabIndex = 20
        '
        'txt12
        '
        Me.txt12.Location = New System.Drawing.Point(355, 177)
        Me.txt12.Multiline = True
        Me.txt12.Name = "txt12"
        Me.txt12.Size = New System.Drawing.Size(58, 29)
        Me.txt12.TabIndex = 19
        '
        'txt11
        '
        Me.txt11.Location = New System.Drawing.Point(262, 177)
        Me.txt11.Multiline = True
        Me.txt11.Name = "txt11"
        Me.txt11.Size = New System.Drawing.Size(58, 29)
        Me.txt11.TabIndex = 18
        '
        'txt10
        '
        Me.txt10.Location = New System.Drawing.Point(626, 131)
        Me.txt10.Multiline = True
        Me.txt10.Name = "txt10"
        Me.txt10.Size = New System.Drawing.Size(58, 29)
        Me.txt10.TabIndex = 17
        '
        'txt9
        '
        Me.txt9.Location = New System.Drawing.Point(538, 131)
        Me.txt9.Multiline = True
        Me.txt9.Name = "txt9"
        Me.txt9.Size = New System.Drawing.Size(58, 29)
        Me.txt9.TabIndex = 16
        '
        'txt8
        '
        Me.txt8.Location = New System.Drawing.Point(448, 131)
        Me.txt8.Multiline = True
        Me.txt8.Name = "txt8"
        Me.txt8.Size = New System.Drawing.Size(58, 29)
        Me.txt8.TabIndex = 15
        '
        'txt7
        '
        Me.txt7.Location = New System.Drawing.Point(355, 131)
        Me.txt7.Multiline = True
        Me.txt7.Name = "txt7"
        Me.txt7.Size = New System.Drawing.Size(58, 29)
        Me.txt7.TabIndex = 14
        '
        'txt6
        '
        Me.txt6.Location = New System.Drawing.Point(262, 131)
        Me.txt6.Multiline = True
        Me.txt6.Name = "txt6"
        Me.txt6.Size = New System.Drawing.Size(58, 29)
        Me.txt6.TabIndex = 13
        '
        'txt5
        '
        Me.txt5.Location = New System.Drawing.Point(626, 85)
        Me.txt5.Multiline = True
        Me.txt5.Name = "txt5"
        Me.txt5.Size = New System.Drawing.Size(58, 29)
        Me.txt5.TabIndex = 12
        '
        'txt4
        '
        Me.txt4.Location = New System.Drawing.Point(538, 85)
        Me.txt4.Multiline = True
        Me.txt4.Name = "txt4"
        Me.txt4.Size = New System.Drawing.Size(58, 29)
        Me.txt4.TabIndex = 11
        '
        'txt3
        '
        Me.txt3.Location = New System.Drawing.Point(448, 85)
        Me.txt3.Multiline = True
        Me.txt3.Name = "txt3"
        Me.txt3.Size = New System.Drawing.Size(58, 29)
        Me.txt3.TabIndex = 10
        '
        'txt2
        '
        Me.txt2.Location = New System.Drawing.Point(355, 85)
        Me.txt2.Multiline = True
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(58, 29)
        Me.txt2.TabIndex = 9
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(262, 85)
        Me.txt1.Multiline = True
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(58, 29)
        Me.txt1.TabIndex = 8
        '
        'txtName5
        '
        Me.txtName5.Location = New System.Drawing.Point(40, 267)
        Me.txtName5.Multiline = True
        Me.txtName5.Name = "txtName5"
        Me.txtName5.Size = New System.Drawing.Size(173, 29)
        Me.txtName5.TabIndex = 7
        '
        'txtName4
        '
        Me.txtName4.Location = New System.Drawing.Point(40, 221)
        Me.txtName4.Multiline = True
        Me.txtName4.Name = "txtName4"
        Me.txtName4.Size = New System.Drawing.Size(173, 29)
        Me.txtName4.TabIndex = 6
        '
        'txtName3
        '
        Me.txtName3.Location = New System.Drawing.Point(40, 177)
        Me.txtName3.Multiline = True
        Me.txtName3.Name = "txtName3"
        Me.txtName3.Size = New System.Drawing.Size(173, 29)
        Me.txtName3.TabIndex = 5
        '
        'txtName2
        '
        Me.txtName2.Location = New System.Drawing.Point(40, 131)
        Me.txtName2.Multiline = True
        Me.txtName2.Name = "txtName2"
        Me.txtName2.Size = New System.Drawing.Size(173, 29)
        Me.txtName2.TabIndex = 4
        '
        'txtName1
        '
        Me.txtName1.Location = New System.Drawing.Point(40, 85)
        Me.txtName1.Multiline = True
        Me.txtName1.Name = "txtName1"
        Me.txtName1.Size = New System.Drawing.Size(173, 29)
        Me.txtName1.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(732, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Average"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(482, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Test Scores"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(95, 62)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(730, 439)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(157, 48)
        Me.btnCalculate.TabIndex = 2
        Me.btnCalculate.Text = "Calculate" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "&Averages"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'MyStudentTestScores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(909, 498)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MyStudentTestScores"
        Me.Text = "Student Test Scores"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuFileSave As ToolStripMenuItem
    Friend WithEvents mnuReport As ToolStripMenuItem
    Friend WithEvents mnuHelp As ToolStripMenuItem
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblAVG6 As Label
    Friend WithEvents txt30 As TextBox
    Friend WithEvents txt29 As TextBox
    Friend WithEvents txt28 As TextBox
    Friend WithEvents txt27 As TextBox
    Friend WithEvents txt26 As TextBox
    Friend WithEvents txtName6 As TextBox
    Friend WithEvents lblAVG5 As Label
    Friend WithEvents lblAVG4 As Label
    Friend WithEvents lblAVG3 As Label
    Friend WithEvents lblAVG2 As Label
    Friend WithEvents lblAVG1 As Label
    Friend WithEvents txt25 As TextBox
    Friend WithEvents txt24 As TextBox
    Friend WithEvents txt23 As TextBox
    Friend WithEvents txt22 As TextBox
    Friend WithEvents txt21 As TextBox
    Friend WithEvents txt20 As TextBox
    Friend WithEvents txt19 As TextBox
    Friend WithEvents txt18 As TextBox
    Friend WithEvents txt17 As TextBox
    Friend WithEvents txt16 As TextBox
    Friend WithEvents txt15 As TextBox
    Friend WithEvents txt14 As TextBox
    Friend WithEvents txt13 As TextBox
    Friend WithEvents txt12 As TextBox
    Friend WithEvents txt11 As TextBox
    Friend WithEvents txt10 As TextBox
    Friend WithEvents txt9 As TextBox
    Friend WithEvents txt8 As TextBox
    Friend WithEvents txt7 As TextBox
    Friend WithEvents txt6 As TextBox
    Friend WithEvents txt5 As TextBox
    Friend WithEvents txt4 As TextBox
    Friend WithEvents txt3 As TextBox
    Friend WithEvents txt2 As TextBox
    Friend WithEvents txt1 As TextBox
    Friend WithEvents txtName5 As TextBox
    Friend WithEvents txtName4 As TextBox
    Friend WithEvents txtName3 As TextBox
    Friend WithEvents txtName2 As TextBox
    Friend WithEvents txtName1 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCalculate As Button
End Class
