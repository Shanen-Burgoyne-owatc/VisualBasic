﻿Imports System.IO
Public Class VideoCollection

    Structure VideoCollection
        Dim nameOfVideo As String
        Dim YearOfProduction As String
        Dim RunTime As String
        Dim ratingForVideo As String
    End Structure

    Dim mytextFile As StreamWriter
    Dim mysearchFile As StreamReader

    Private Sub mnuSave_Click(sender As Object, e As EventArgs) Handles mnuSave.Click
        Dim videoRecord As VideoCollection

        videoRecord.nameOfVideo = txtVideoName.Text
        videoRecord.YearOfProduction = CType(Convert.ToInt32(txtYearProduced.Text), String)
        videoRecord.RunTime = txtRunningTime.Text
        videoRecord.ratingForVideo = txtRating.Text

        mytextFile = File.CreateText("D:\VideoCollection.txt")
        mytextFile.WriteLine(videoRecord.nameOfVideo)
        mytextFile.WriteLine(videoRecord.YearOfProduction)
        mytextFile.WriteLine(videoRecord.RunTime)
        mytextFile.WriteLine(videoRecord.ratingForVideo)
        mytextFile.Close()
        Reset()
    End Sub

    Private Sub mnuReport_Click(sender As Object, e As EventArgs) Handles mnuReport.Click
        Dim videoReport As String
        videoReport = "Report of Video Collection" + vbNewLine

        mysearchFile = File.OpenText("D:\VideoCollection.txt")

        Try
            While Not mysearchFile.EndOfStream
                videoReport += mysearchFile.ReadLine() + ""
                videoReport += mysearchFile.ReadLine() + ""
                videoReport += mysearchFile.ReadLine() + ""
                videoReport += mysearchFile.ReadLine() + ""
                videoReport += mysearchFile.ReadLine() + ""
                videoReport += vbNewLine
            End While
        Catch
        End Try

        MessageBox.Show(videoReport)
    End Sub

    Private Sub mnuSearch_Click(sender As Object, e As EventArgs) Handles mnuSearch.Click
        mysearchFile = File.OpenText("D:\VideoCollection.txt")

        Dim saveName As String
        Dim flagValue As Integer

        flagValue = 0

        saveName = InputBox("Enter Video Name")

        Dim videoSearchRecord As VideoCollection

        Try
            While Not mysearchFile.EndOfStream
                videoSearchRecord.nameOfVideo = mysearchFile.ReadLine()
                videoSearchRecord.YearOfProduction = mysearchFile.Readline()
                videoSearchRecord.RunTime = mysearchFile.ReadLine()
                videoSearchRecord.ratingForVideo = mysearchFile.Readline()

                If videoSearchRecord.nameOfVideo.Equals(saveName) Then
                    flagValue = 1
                    Exit While
                End If
            End While

            If flagValue.Equals(1) Then
                txtVideoName.Text = videoSearchRecord.nameOfVideo.ToString()
                txtYearProduced.Text = videoSearchRecord.YearOfProduction.ToString()
                txtRunningTime.Text = videoSearchRecord.RunTime.ToString()
                txtRating.Text = videoSearchRecord.ratingForVideo.ToString()
            Else
                MessageBox.Show("Records don't exist")
                Reset()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub mnuClose_Click(sender As Object, e As EventArgs) Handles mnuClose.Click
        Me.Close()
    End Sub

    Private Sub mnuHelp_Click(sender As Object, e As EventArgs) Handles mnuHelp.Click
        MessageBox.Show("1. Enter the Video Data in the TextBoxes and click save to save information." +
                        "2. Click Report menu to generate a report of video information saved in the file." +
                        "3. Click search to the video information saved already.")
    End Sub

    Public Sub reset()
        txtVideoName.Text = String.Empty
        txtRunningTime.Text = String.Empty
        txtYearProduced.Text = String.Empty
        txtRating.Text = String.Empty
    End Sub
End Class
