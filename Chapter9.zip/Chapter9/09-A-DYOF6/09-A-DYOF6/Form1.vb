﻿Imports System.IO
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim readFile As StreamReader

        readFile = File.OpenText("NumberSet.txt")

        Dim count As Integer = 0
        Dim number As Double
        Dim total As Double = 0
        Dim avg As Double
        Dim min As Double = 1000
        Dim max As Double = 0

        While Not readFile.EndOfStream

            number = Convert.ToDouble(readFile.ReadLine())

            total += number
            count += 1

            If (number > max) Then
                max = number
            End If

            If (number < min) Then
                min = number
            End If
        End While

        avg = total / count

        txtTotal.Text = Format(total, "0.00")
        txtAvg.Text = Format(avg, "0.00")
        txtMax.Text = Format(max, "0.00")
        txtMin.Text = Format(min, "0.00")
    End Sub
End Class
