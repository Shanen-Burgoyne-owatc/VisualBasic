﻿Public Class Form1
    Private Sub mnuFileOpen_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click
        Dim fileName As String

        With ofdOpenFile

            .Filter = "Jpeg images (*.jpg)|*.jpg|Bitmaps (*.bmp)|*bmp|GIF images (*gif)|*.gif"

            .FileName = ""

            .InitialDirectory = "C:\Users\Public|pictures\Sample Pictures"

            .Title = "Select an Image to open"

            If ofdOpenFile.ShowDialog() =
                    Windows.Forms.DialogResult.OK Then

                fileName = ofdOpenFile.FileName
                picImage.Image = Image.FromFile(fileName)
            Else
                MessageBox.Show("You selected no file.")
            End If
        End With
    End Sub
End Class
