﻿Public Class Form1
    Private Sub mnuFont_Click(sender As Object, e As EventArgs) Handles cdFont.Click
        fdFont.ShowColor = True

        If fdFont.ShowDialog() = Windows.Forms.DialogResult.OK Then
            lblText.Font = fdFont.Font
            lblText.ForeColor = fdFont.Color
        End If
    End Sub

    Private Sub mnuColor_Click(sender As Object, e As EventArgs) Handles mnuColor.Click
        If cdColor.ShowDialog() = Windows.Forms.DialogResult.OK Then
            lblText.BackColor = cdColor.Color
        End If
    End Sub
End Class
