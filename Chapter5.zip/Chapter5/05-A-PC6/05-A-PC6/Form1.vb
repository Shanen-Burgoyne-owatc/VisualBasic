﻿Public Class Form1
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim strUserInput As String
        Dim intCount As Integer
        Dim intUserInput As Integer



        For intCount = 1 To 5

            'Prompt the user for the input of sales each day
            strUserInput = InputBox($"Please enter the amount of sales for day {intCount}: ")
            If Integer.TryParse(strUserInput, intUserInput) Then
                Dim strStars As String = ""
                For index = 1 To intUserInput / 100
                    strStars += "*"
                Next
                lstOutput.Items.Add($"Store {intCount}: {strStars} ")
            End If

        Next
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
