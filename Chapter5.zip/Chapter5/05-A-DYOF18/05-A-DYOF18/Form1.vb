﻿Public Class Form1
    Dim intAnswer As Integer

    Public Sub New()
        InitializeComponent()
        Dim rand As New Random
        intAnswer = rand.Next(1, 100)

    End Sub
    Private Sub btnGuess_Click(sender As Object, e As EventArgs) Handles btnGuess.Click

        Dim intGuess As Integer
        intGuess = CInt(txtGuess.Text)

        If intGuess > intAnswer Then
            lblAnswer.Text = "Too high, try again."
        ElseIf intGuess < intAnswer Then
            lblAnswer.Text = "Too low, try again."
        ElseIf intGuess = intAnswer Then
            lblAnswer.Text = "Correct!"
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        txtGuess.Clear()

        lblAnswer.Text = String.Empty

        txtGuess.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
