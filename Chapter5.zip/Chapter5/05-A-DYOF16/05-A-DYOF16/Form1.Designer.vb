﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.picSide1 = New System.Windows.Forms.PictureBox()
        Me.picSide2 = New System.Windows.Forms.PictureBox()
        Me.btnRoll = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.picSide1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSide2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picSide1
        '
        Me.picSide1.Image = CType(resources.GetObject("picSide1.Image"), System.Drawing.Image)
        Me.picSide1.Location = New System.Drawing.Point(65, 41)
        Me.picSide1.Name = "picSide1"
        Me.picSide1.Size = New System.Drawing.Size(114, 102)
        Me.picSide1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSide1.TabIndex = 0
        Me.picSide1.TabStop = False
        '
        'picSide2
        '
        Me.picSide2.Image = CType(resources.GetObject("picSide2.Image"), System.Drawing.Image)
        Me.picSide2.Location = New System.Drawing.Point(280, 41)
        Me.picSide2.Name = "picSide2"
        Me.picSide2.Size = New System.Drawing.Size(114, 102)
        Me.picSide2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSide2.TabIndex = 1
        Me.picSide2.TabStop = False
        '
        'btnRoll
        '
        Me.btnRoll.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRoll.Location = New System.Drawing.Point(25, 282)
        Me.btnRoll.Name = "btnRoll"
        Me.btnRoll.Size = New System.Drawing.Size(179, 80)
        Me.btnRoll.TabIndex = 6
        Me.btnRoll.Text = "ROLL!"
        Me.btnRoll.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(250, 282)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(179, 80)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "Die1.BMP")
        Me.ImageList1.Images.SetKeyName(1, "Die2.BMP")
        Me.ImageList1.Images.SetKeyName(2, "Die3.BMP")
        Me.ImageList1.Images.SetKeyName(3, "Die4.BMP")
        Me.ImageList1.Images.SetKeyName(4, "Die5.BMP")
        Me.ImageList1.Images.SetKeyName(5, "Die6.BMP")
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(488, 397)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnRoll)
        Me.Controls.Add(Me.picSide2)
        Me.Controls.Add(Me.picSide1)
        Me.Name = "Form1"
        Me.Text = "What's Your Roll?"
        CType(Me.picSide1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSide2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picSide1 As PictureBox
    Friend WithEvents picSide2 As PictureBox
    Friend WithEvents btnRoll As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ImageList1 As ImageList
End Class
