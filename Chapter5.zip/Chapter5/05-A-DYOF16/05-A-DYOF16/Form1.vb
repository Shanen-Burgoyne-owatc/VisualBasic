﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnRoll.Click

        Dim rand As Random = New Random

        picSide1.Image = ImageList1.Images(rand.Next(0, 6))
        picSide2.Image = ImageList1.Images(rand.Next(0, 6))
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
