﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intcount As Integer = 1
        Dim intVehicleSpeed As Integer
        Dim intTimeTraveled As Integer
        Dim intTotalDistance As Integer
        Dim intDistanceTraveled As Integer
        Dim strInputVehicleSpeed As String
        Dim strInputTimeTraveled As String

        ' Prompts the user for the vehicle speed, and time traveled
        strInputVehicleSpeed = InputBox("Vehicle Speed: ")
        strInputTimeTraveled = InputBox("Time Traveled: ")

        If Integer.TryParse(strInputVehicleSpeed, intVehicleSpeed) Then
            If Integer.TryParse(strInputTimeTraveled, intTimeTraveled) Then
                lstOutput.Items.Add("Vehicle Speed:   " & intVehicleSpeed)
                lstOutput.Items.Add("Hours Traveled:   " & intTimeTraveled)
                lstOutput.Items.Add("Hours      Distance Traveled")
                lstOutput.Items.Add("-------------------------------------------")
                Do Until intcount > intTimeTraveled

                    intDistanceTraveled = intcount * intVehicleSpeed
                    lstOutput.Items.Add(intcount & "                        " & intDistanceTraveled.ToString())
                    intcount += 1
                Loop
                intTotalDistance = intVehicleSpeed * intTimeTraveled
                lstOutput.Items.Add("Total Distance:   " & intTotalDistance)
            End If
        End If



    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
