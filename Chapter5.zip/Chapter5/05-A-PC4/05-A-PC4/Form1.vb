﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intcount As Integer
        Dim intNumberOfRooms As Integer
        Dim intTotalRoomsOccupied As Integer
        Dim dblOccupancyRate As Double
        Dim strInput As String
        Dim dblOccupancyRateTotal As Double



        For intcount = 1 To 8
            'Prompt the user for the number of floors.
            strInput = InputBox($"How many rooms are occupied on floor {intcount}?")
            If Integer.TryParse(strInput, intNumberOfRooms) Then
                dblOccupancyRate = intNumberOfRooms / 30
                lstOutput.Items.Add($"Floor: {intcount} Rooms Occupied: " & intNumberOfRooms & " Occupancy Rate: " & dblOccupancyRate.ToString("p"))
                intTotalRoomsOccupied += intNumberOfRooms
            End If
        Next
        lblTotal.Text = intTotalRoomsOccupied.ToString()
        dblOccupancyRateTotal = intTotalRoomsOccupied / 240
        lblOccupancyRateTotal.Text = dblOccupancyRateTotal.ToString("p")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstOutput.Items.Clear()
        lblTotal.Text = String.Empty
        lblOccupancyRateTotal.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
