﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intOrganisms As Integer
        Dim intNumberofDays As Integer
        Dim dblIncreaseRate As Double
        Dim dblAveragePopulation As Double

        intOrganisms = CInt(cboOrganisms.Text)
        intNumberofDays = CInt(cboDays.Text)
        dblIncreaseRate = CDbl(txtIncrease.Text) * 0.01

        lstOutput.Items.Add("Day                Approximate Population")
        lstOutput.Items.Add("----------------------------------------------------------")
        For index = 1 To intNumberofDays
            If index = 1 Then
                dblAveragePopulation = intOrganisms
            Else
                dblAveragePopulation += dblAveragePopulation * dblIncreaseRate
            End If
            lstOutput.Items.Add($"{index}                       {dblAveragePopulation} ")
        Next
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
