﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intNumberofDays As Integer
        Dim decTotalPennies As Decimal
        Dim decStartpennies As Decimal = 0.01D
        Dim intIncrease As Integer = 2

        intNumberofDays = CInt(cboDays.Text)

        For index = 1 To intNumberofDays

            If intNumberofDays = 1 Then
                decStartpennies = 0.01D
                decTotalPennies = decStartpennies
            ElseIf index >= 2 Then
                decTotalPennies += decStartpennies * intIncrease
            End If
            lblTotal.Text = decTotalPennies.ToString("C")
        Next
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
