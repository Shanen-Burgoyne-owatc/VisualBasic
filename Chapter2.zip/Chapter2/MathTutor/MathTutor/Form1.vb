﻿Public Class Form1
    Private Sub btnShowAnswer_Click(sender As Object, e As EventArgs) Handles btnShowAnswer.Click
        ' Displays the answer to the Problem
        lblAnswer.Text = "18 + 64 = 82"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Closes the Application
        Me.Close()
    End Sub
End Class
