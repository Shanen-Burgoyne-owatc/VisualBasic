﻿Public Class frmDirections
    Private Sub btnDisplayDirections_Click(sender As Object, e As EventArgs) Handles btnDisplayDirections.Click
        'Makes the Directions Visible.
        lblDirections.Visible = True
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Closes the Window
        Me.Close()
    End Sub
End Class
