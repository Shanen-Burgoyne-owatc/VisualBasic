﻿Public Class Form1
    Private Sub btnSinster_Click(sender As Object, e As EventArgs) Handles btnSinster.Click
        ' Displays the English word Left
        lblLeft.Text = "Left"
    End Sub

    Private Sub btnMedium_Click(sender As Object, e As EventArgs) Handles btnMedium.Click
        ' Displays the English word Center
        lblCenter.Text = "Center"
    End Sub

    Private Sub btnDexter_Click(sender As Object, e As EventArgs) Handles btnDexter.Click
        ' Displays the English word Right
        lblRight.Text = "Right"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
