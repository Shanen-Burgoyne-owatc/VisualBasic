﻿Public Class Form1
    Private Sub btnVirginia_Click(sender As Object, e As EventArgs) Handles btnVirginia.Click
        ' Display the Abbreviation for Virginia
        lblAnswer.Text = "VA"
    End Sub

    Private Sub btnNC_Click(sender As Object, e As EventArgs) Handles btnNC.Click
        ' Display the Abbreviation for North Carolina
        lblAnswer.Text = "NC"
    End Sub

    Private Sub btnSC_Click(sender As Object, e As EventArgs) Handles btnSC.Click
        ' Display the Abbreviation for South Carolina
        lblAnswer.Text = "SC"
        lblAnswer.Visible = True
    End Sub

    Private Sub btnGeorgia_Click(sender As Object, e As EventArgs) Handles btnGeorgia.Click
        ' Display the Abbreviation for Gerogia
        lblAnswer.Text = "GA"
    End Sub

    Private Sub btnAlabama_Click(sender As Object, e As EventArgs) Handles btnAlabama.Click
        ' Display the Abbreviation for Alabama
        lblAnswer.Text = "AL"
    End Sub

    Private Sub btnFlorida_Click(sender As Object, e As EventArgs) Handles btnFlorida.Click
        ' Display the Abbreviation for Florida
        lblAnswer.Text = "FL"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
