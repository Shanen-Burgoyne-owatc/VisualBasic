﻿Public Class Form1
    Private Sub pic1_Click(sender As Object, e As EventArgs) Handles pic1.Click
        ' Displays the Word One
        lblAnswer.Text = "One"
    End Sub

    Private Sub pic2_Click(sender As Object, e As EventArgs) Handles pic2.Click
        ' Displays the word Two
        lblAnswer.Text = "Two"
    End Sub

    Private Sub pic3_Click(sender As Object, e As EventArgs) Handles pic3.Click
        ' Displays the word Three
        lblAnswer.Text = "Three"
    End Sub

    Private Sub pic4_Click(sender As Object, e As EventArgs) Handles pic4.Click
        ' Displays the word Four
        lblAnswer.Text = "Four"
    End Sub

    Private Sub pic5_Click(sender As Object, e As EventArgs) Handles pic5.Click
        ' Displays the word Five
        lblAnswer.Text = "Five"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class
