﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Closes the Form
        Me.Close()
    End Sub
End Class
