﻿Public Class cRental
    Private Flat As Integer
    Private House As Integer
    Private Unit As Integer
    Private Cost As Double
    Private NumOfRooms As Integer
    Private Location As String


    Public Property cFlat() As Integer
        Set(value As Integer)
            Flat = value
        End Set
        Get
            Return Flat
        End Get
    End Property

    Public Property cHouse() As Integer
        Set(value As Integer)
            House = value
        End Set
        Get
            Return House
        End Get
    End Property

    Public Property cUnit() As Integer
        Set(value As Integer)
            Unit = value
        End Set
        Get
            Return Unit
        End Get
    End Property

    Public Property cCost() As Double
        Set(value As Double)
            Cost = value
        End Set
        Get
            Return Cost
        End Get
    End Property

    Public Property cNumOfRooms() As Integer
        Set(value As Integer)
            NumOfRooms = value
        End Set
        Get
            Return NumOfRooms
        End Get
    End Property

    Public Property cLocation() As String
        Set(value As String)
            Location = value
        End Set
        Get
            Return Location
        End Get
    End Property


End Class

Public Class cCustomer
    Private CustomerID As String
    Private Firstname As String
    Private Surname As String
    Private Address As String
    Private ZipCode As String
    Private Town As String
    Private ProofOfID As String

    Private Deposit As Double
    Private DownPayment As Double


    Public Property cCustomerID() As String
        Set(value As String)
            CustomerID = value
        End Set
        Get
            Return CustomerID
        End Get
    End Property

    Public Property cFirstname() As String
        Set(value As String)
            Firstname = value
        End Set
        Get
            Return Firstname
        End Get
    End Property

    Public Property cSurname() As String
        Set(value As String)
            Surname = value
        End Set
        Get
            Return Surname
        End Get
    End Property

    Public Property cAddress() As String
        Set(value As String)
            Address = value
        End Set
        Get
            Return Address
        End Get
    End Property

    Public Property cZipCode() As String
        Set(value As String)
            ZipCode = value
        End Set
        Get
            Return ZipCode
        End Get
    End Property

    Public Property cTown() As String
        Set(value As String)
            Town = value
        End Set
        Get
            Return Town
        End Get
    End Property

    Public Property cProofOfID() As String
        Set(value As String)
            ProofOfID = value
        End Set
        Get
            Return ProofOfID
        End Get
    End Property

    Public Property cDeposit() As Double
        Set(value As Double)
            Deposit = value
        End Set
        Get
            Return Deposit
        End Get
    End Property

    Public Property cDownPayment() As Double
        Set(value As Double)
            DownPayment = value
        End Set
        Get
            Return DownPayment
        End Get
    End Property
End Class

Public Class cUtilities
    Private LocalTax As Double
    Private Water As Double
    Private Electricity As Double

    Public Property cLocalTax() As Double
        Set(value As Double)
            LocalTax = value
        End Set
        Get
            Return LocalTax
        End Get
    End Property

    Public Property cWater() As Double
        Set(value As Double)
            Water = value
        End Set
        Get
            Return Water
        End Get
    End Property

    Public Property cElectricity() As Double
        Set(value As Double)
            Electricity = value
        End Set
        Get
            Return Electricity
        End Get
    End Property

End Class

Public Class BillingCost
    Public ICusotmer As New cCustomer
    Public IRental As New cRental
    Public IUtilities As New cUtilities


    Public Overridable Function TotalBill()
        Return (ICusotmer.cDeposit + ICusotmer.cDownPayment + (IRental.cCost * IRental.cNumOfRooms) + IUtilities.cLocalTax +
            IUtilities.cElectricity + IUtilities.cWater)
    End Function
End Class