﻿Imports System.IO

Public Class Form1

    Private strFilename As String = String.Empty
    Dim blnIsChanged As Boolean = False


    Dim iBilling As New BillingCost
    Private Sub txtCustomerID_TextChanged(sender As Object, e As EventArgs) Handles txtCustomerID.TextChanged

    End Sub

    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click

        iBilling.ICusotmer.cDeposit = Val(txtDeposit.Text)
        iBilling.ICusotmer.cDownPayment = Val(txtDownPayment.Text)
        iBilling.IUtilities.cElectricity = Val(txtElectricity.Text)
        iBilling.IUtilities.cLocalTax = Val(txtLocalTax.Text)
        iBilling.IUtilities.cWater = Val(txtWaterBill.Text)
        iBilling.IRental.cCost = Val(txtCost.Text)
        iBilling.IRental.cNumOfRooms = Val(nudRoom.Value)

        lblTotalPayment.Text = FormatCurrency(iBilling.TotalBill)


        rtReceipt.Visible = True

        rtReceipt.AppendText("Oleson Property Rentals" + vbNewLine + "--------------------------------------------" + vbNewLine)
        rtReceipt.AppendText("Customer ID: " + txtCustomerID.Text + vbNewLine)
        rtReceipt.AppendText("First Name:     " + txtFirstName.Text + vbNewLine)
        rtReceipt.AppendText("Last Name:     " + txtLastName.Text + vbNewLine)
        rtReceipt.AppendText("Address:     " + txtAddress.Text + vbNewLine)
        rtReceipt.AppendText("ZipCode:     " + txtZipCode.Text + vbNewLine)
        rtReceipt.AppendText("Proof of ID:     " + cboProofOfID.Text + vbNewLine)
        rtReceipt.AppendText("City:     " + txtCity.Text + vbNewLine)
        rtReceipt.AppendText("--------------------------------------------" + vbNewLine)
        rtReceipt.AppendText("Deposit:     " + txtDeposit.Text + vbNewLine)
        rtReceipt.AppendText("Down Payment:     " + txtDownPayment.Text + vbNewLine)

        If RadFloor.Checked = True Then
            rtReceipt.AppendText("Property type:     " + RadFloor.Text + vbNewLine)
        End If

        If RadHouse.Checked = True Then
            rtReceipt.AppendText("Property type:     " + RadHouse.Text + vbNewLine)
        End If

        If RadStorageUnit.Checked = True Then
            rtReceipt.AppendText("Property type:     " + RadStorageUnit.Text + vbNewLine)
        End If

        rtReceipt.AppendText("Number of Units:     " + nudRoom.Text + vbNewLine)

        rtReceipt.AppendText("Electricity:     " + txtElectricity.Text + vbNewLine)
        rtReceipt.AppendText("Local Tax:     " + txtLocalTax.Text + vbNewLine)
        rtReceipt.AppendText("Water:     " + txtWaterBill.Text + vbNewLine)
        rtReceipt.AppendText("--------------------------------------------" + vbNewLine)
        rtReceipt.AppendText("Total Payment:     " + lblTotalPayment.Text + vbNewLine)
        rtReceipt.AppendText("--------------------------------------------" + vbNewLine)

        lblTotalPayment.Visible = True
        Label20.Visible = True

        btnConfirm.Enabled = False

    End Sub


    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        For Each txt In Panel3.Controls.OfType(Of TextBox)
            txt.Text = ""
        Next

        For Each txt In Panel4.Controls.OfType(Of TextBox)
            txt.Text = ""
        Next

        For Each txt In Panel5.Controls.OfType(Of TextBox)
            txt.Text = ""
        Next

        For Each txt In Panel2.Controls.OfType(Of TextBox)
            txt.Text = ""
        Next

        nudRoom.Value = 1
        rtReceipt.Clear()
        cboLocation.Text = String.Empty
        cboProofOfID.Text = String.Empty

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        systemExit.ExitSystem()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboLocation.Items.Add("Roy Storage Units")
        cboLocation.Items.Add("5160 2050 W St, Roy")
        cboLocation.Items.Add("5145 2150 W St, Roy")

        cboProofOfID.Items.Add("Driver's License")
        cboProofOfID.Items.Add("Government ID")
        cboProofOfID.Items.Add("Student ID Card")
    End Sub

    Private Sub pdPrint_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles pdPrint.PrintPage
        e.Graphics.DrawString(rtReceipt.Text, New Font("MS Sans Serif", 12, FontStyle.Regular), Brushes.Black, 10, 10)
    End Sub

    Private Sub mnuFilePrint_Click(sender As Object, e As EventArgs) Handles mnuFilePrint.Click
        pdPrint.Print()
    End Sub

    Sub SaveDocument()
        Dim OutputFile = File.CreateText(strFilename)

        Try
            OutputFile.Write(rtReceipt.Text)

            OutputFile.Close()

            blnIsChanged = False
        Catch
            MessageBox.Show("Error creating the file.")
        End Try
    End Sub

    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click
        If strFilename = String.Empty Then
            ' The Document has not been saved, so use Save As Dialog box.
            If sfdSaveFile.ShowDialog = Windows.Forms.DialogResult.OK Then
                strFilename = sfdSaveFile.FileName
                SaveDocument()
            End If
        Else
            ' Save the document with the Current filename
            SaveDocument()
        End If
    End Sub

    Private Sub mnuFileSaveAs_Click(sender As Object, e As EventArgs) Handles mnuFileSaveAs.Click
        If sfdSaveFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            strFilename = sfdSaveFile.FileName
            SaveDocument()
        End If
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        ' If the document has been modified, confirm before exiting.
        If blnIsChanged = True Then
            If MessageBox.Show("The current document is not saved. " & "Do you wish to discard your changes?",
                                "Confirm",
                                MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                e.Cancel = False
            Else
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        systemExit.ExitSystem()
    End Sub
End Class

Public Class systemExit

    Public Shared Function ExitSystem()
        Dim iExit As DialogResult
        iExit = MessageBox.Show("Confirm if you want to exit", "Oleson Rental System", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If iExit = DialogResult.Yes Then
            Application.Exit()
        End If
    End Function
End Class