﻿Public Class Form1

    Private intDays As Integer
    Private intMedication As Integer
    Private intSurgery As Integer
    Private intLabs As Integer
    Private intPhyscial As Integer
    Private intBaseFee As Integer = 350
    Private intMisc As Integer

    Private Function ValidateInputFields() As Boolean
        ' Try and convert each of the input fields. Return False if any field is invalid
        ' and display a suitable error message.

        If Not Integer.TryParse(txtDays.Text, intDays) Then
            MessageBox.Show("Length of hospital stay should be an integer.")
            Return False
        End If

        If Not Integer.TryParse(txtMedication.Text, intMedication) Then
            MessageBox.Show("Medication charges should be in integer format.")
            Return False
        End If

        If Not Integer.TryParse(txtSurgery.Text, intSurgery) Then
            MessageBox.Show("Surgery Charges should be in integer format.")
            Return False
        End If

        If Not Integer.TryParse(txtLabs.Text, intLabs) Then
            MessageBox.Show("Lab Fees need to be in integer format.")
            Return False
        End If

        If Not Integer.TryParse(txtPhysical.Text, intPhyscial) Then
            MessageBox.Show("Phsical Therapy charges need to be in integer format.")
            Return False
        End If

        Return True
    End Function

    Function CalcStayCharges(ByVal intDays As Integer,
                             ByVal intBaseFee As Integer) As Integer
        ' Calculates and returns the Hospital stay charges.
        Dim intHospitalStay As Integer

        intHospitalStay = intBaseFee * intDays
        Return intHospitalStay
    End Function

    Function CalcMiscCharges(ByVal intMedication As Integer, ByVal intSurgery As Integer,
                             ByVal intLabs As Integer, ByVal intPhysical As Integer) As Integer
        ' Calculates and returns the miscellaneous charges.
        Dim intMisc = intMedication + intSurgery + intLabs + intPhyscial
        Return intMisc
    End Function

    Function CalcTotalCharges(stay As Integer, misc As Integer) As Integer
        Return stay + misc
    End Function
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim intHospitalStay As Integer

        ' If the input is valid, display the charges.
        If ValidateInputFields() Then
            intHospitalStay = CalcStayCharges(intDays, intBaseFee)
            lblTotalCost.Text = intHospitalStay.ToString("C")
        End If
        intMisc = CalcMiscCharges(intMedication, intSurgery, intLabs, intPhyscial)
        lblTotalCost.Text = CalcTotalCharges(intHospitalStay, intMisc).ToString("C")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtDays.Text = String.Empty
        txtLabs.Text = String.Empty
        txtMedication.Text = String.Empty
        txtSurgery.Text = String.Empty
        txtPhysical.Text = String.Empty

        lblTotalCost.Text = String.Empty

        txtDays.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
