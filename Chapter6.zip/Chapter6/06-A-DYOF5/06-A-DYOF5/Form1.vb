﻿Public Class Form1

    Function IsValid(ByVal Password As String,
    Optional ByVal minLength As Integer = 6) As Boolean


        Dim lower As New System.Text.RegularExpressions.Regex("[a-z]")
        Dim number As New System.Text.RegularExpressions.Regex("[0-9]")

        If Len(Password) < minLength Then
            Return False
        End If

        If lower.Matches(Password).Count < 1 Then
            Return False
        End If

        If number.Matches(Password).Count < 1 Then
            Return False
        End If

        Return True
    End Function

    Private Sub btnVerify_Click(sender As Object, e As EventArgs) Handles btnVerify.Click
        If IsValid(txtPassword.Text) Then
            MessageBox.Show("Password is verified")
        Else
            MessageBox.Show("Password does not meet criteria.")
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtPassword.Text = String.Empty
        txtPassword.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
