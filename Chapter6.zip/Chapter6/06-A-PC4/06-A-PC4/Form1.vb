﻿Public Class Form1
    'Class Declarations
    Const decOil As Decimal = 26D
    Const declube As Decimal = 18D
    Const decRadiator As Decimal = 30D
    Const decTransmission As Decimal = 80D
    Const decInspection As Decimal = 15D
    Const decMuffler As Decimal = 100D
    Const decTire As Decimal = 20D
    Const decTax As Decimal = 0.06D     'Taxes on Parts only

    Function OilLubeCharges() As Decimal
        Dim decOilLube As Decimal = 0D

        If chkOil.Checked = True Then
            decOilLube += decOil
        End If

        If chkLube.Checked = True Then
            decOilLube += declube
        End If

        Return decOilLube
    End Function

    Function FlushCharges() As Decimal
        Dim decFlushCharges = 0D

        If chkRadiator.Checked = True Then
            decFlushCharges += decRadiator
        End If

        If chkTransmission.Checked = True Then
            decFlushCharges += decTransmission
        End If

        Return decFlushCharges
    End Function

    Function MiscCharges() As Decimal
        Dim decMiscCharges = 0D

        If chkInspection.Checked = True Then
            decMiscCharges += decInspection
        End If

        If chkMuffler.Checked = True Then
            decMiscCharges += decMuffler
        End If

        If chkTireRotation.Checked = True Then
            decMiscCharges += decTire
        End If

        Return decMiscCharges
    End Function

    Function OtherCharges() As Decimal
        Dim laborPartCharges As Decimal = 0D
        If (txtLabor.Text <> "" Or txtParts.Text <> "") Then

            If IsNumeric(txtLabor.Text) And IsNumeric(txtParts.Text) Then

                Dim intLabor As Integer = Convert.ToInt32(txtLabor.Text)
                laborPartCharges = intLabor * 20
                laborPartCharges += Convert.ToDecimal(txtParts.Text)
            Else
                MessageBox.Show("Please enter Numeric values only")
            End If
        End If
        Return laborPartCharges
    End Function

    Function TaxCharges() As Decimal

        If IsNumeric(txtParts.Text) Then
            Return Convert.ToDecimal(txtParts.Text) * decTax
        End If

        Return 0
    End Function

    Function TotalCharges() As Decimal

        Return OilLubeCharges() + FlushCharges() + MiscCharges() + OtherCharges() + TaxCharges()
    End Function

    Sub ClearOilLube()
        chkLube.Checked = False
        chkOil.Checked = False
    End Sub

    Sub ClearFlushes()
        chkRadiator.Checked = False
        chkTransmission.Checked = False
    End Sub

    Sub ClearMisc()
        chkInspection.Checked = False
        chkMuffler.Checked = False
        chkTireRotation.Checked = False
    End Sub

    Sub ClearOther()
        txtLabor.Text = String.Empty
        txtParts.Text = String.Empty
    End Sub

    Sub ClearFees()
        lblServices.Text = String.Empty
        lblParts.Text = String.Empty
        lblTaxes.Text = String.Empty
        lblTotal.Text = String.Empty
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Calculates the total of the orders
        Dim decServices As Decimal
        Dim decParts As Decimal
        Dim dectax As Decimal
        Dim decTotal As Decimal


        decServices = OilLubeCharges() + FlushCharges() + MiscCharges()
        decParts = OtherCharges()
        dectax = TaxCharges()
        decTotal = TotalCharges()


        lblServices.Text = decServices.ToString("C")
        lblParts.Text = decParts.ToString("C")
        lblTaxes.Text = dectax.ToString("C")
        lblTotal.Text = decTotal.ToString("C")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearOilLube()
        ClearFlushes()
        ClearMisc()
        ClearOther()
        ClearFees()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
