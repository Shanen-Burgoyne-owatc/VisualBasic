﻿Public Class Form1

    ' Class-level declarations
    Const decTax_Rate As Decimal = 0.06D        ' Tax Rate
    Const decWhite_Bagel As Decimal = 1.25D     ' Cost of a white Bagel
    Const decWheat_Bagel As Decimal = 1.5D      ' Cost of a whole wheat bagel
    Const decCream_Cheese As Decimal = 0.5D     ' Cost of cream cheese topping
    Const decButter As Decimal = 0.25D          ' Cost of butter topping
    Const decBlueberry As Decimal = 0.75D        ' Cost of bluberry topping
    Const decRaspberry As Decimal = 0.75D       ' Cost of raspberry topping
    Const decPeach As Decimal = 0.75D           ' Cost of Peach topping
    Const decReg_Coffee As Decimal = 1.25D      ' Cost of regular coffee
    Const decCappucino As Decimal = 2D          ' Cost of cappucino
    Const decCafe_Au_Lait As Decimal = 1.75D    ' Cost of Cafe au lait
    Function CalcBagelCost() As Decimal
        ' This function returns the cost of the selected bagel.
        Dim decBagel As Decimal

        If radWhite.Checked = True Then
            decBagel = decWhite_Bagel
        Else
            decBagel = decWheat_Bagel
        End If
        Return decBagel
    End Function

    Function CalcToppingCost() As Decimal
        ' This function returns the cost of the toppings.
        Dim decCostOfTopping As Decimal = 0D

        If chkCreamCheese.Checked = True Then
            decCostOfTopping += decCream_Cheese
        End If

        If chkButter.Checked = True Then
            decCostOfTopping += decButter
        End If

        If chkBlueberry.Checked = True Then
            decCostOfTopping += decBlueberry
        End If

        If chkRaspberry.Checked = True Then
            decCostOfTopping += decRaspberry
        End If

        If chkPeach.Checked = True Then
            decCostOfTopping += decPeach
        End If

        Return decCostOfTopping
    End Function

    Function CalcCoffeeCost() As Decimal
        'This function returns the cost of the selected coffee.
        Dim decCoffee As Decimal

        If radNoCoffee.Checked = True Then
            decCoffee = 0D
        ElseIf radRegCoffee.Checked = True Then
            decCoffee = decReg_Coffee
        ElseIf radCappuccino.Checked = True Then
            decCoffee = decCappucino
        ElseIf radCafeAuLait.Checked = True Then
            decCoffee = decCafe_Au_Lait
        End If

        Return decCoffee
    End Function

    Function CalcTax(ByVal decAmount As Decimal) As Decimal
        ' This function recieves the sale amount and returns the amount of sales tax.
        Return decAmount * decTax_Rate
    End Function

    Sub ResetBagels()
        ' This procedure resets the bagel selection.
        radWhite.Checked = True
    End Sub

    Sub ResetToppings()
        ' This procedure resets the topping selection.
        chkCreamCheese.Checked = False
        chkButter.Checked = False
        chkBlueberry.Checked = False
        chkRaspberry.Checked = False
        chkPeach.Checked = False
    End Sub

    Sub ResetCoffee()
        ' This procedure resets the coffee selection.
        radRegCoffee.Checked = True
    End Sub

    Sub ResetPrice()
        ' This procedure resets the price.
        lblSubtotal.Text = String.Empty
        lblTax.Text = String.Empty
        lblTotal.Text = String.Empty
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' This procedure calculates the total of an order.
        Dim decSubtotal As Decimal              ' Holds the order subtotal
        Dim decTax As Decimal                   ' Holds the sales tax
        Dim decTotal As Decimal                 ' Holds the order total

        decSubtotal = CalcBagelCost() + CalcToppingCost() + CalcCoffeeCost()
        decTax = CalcTax(decSubtotal)
        decTotal = decSubtotal + decTax

        lblSubtotal.Text = decSubtotal.ToString("C")
        lblTax.Text = decTax.ToString("C")
        lblTotal.Text = decTotal.ToString("C")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' This procedure resets the controls to default values.
        ResetBagels()
        ResetToppings()
        ResetCoffee()
        ResetPrice()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Close the form.
        Me.Close()
    End Sub
End Class
