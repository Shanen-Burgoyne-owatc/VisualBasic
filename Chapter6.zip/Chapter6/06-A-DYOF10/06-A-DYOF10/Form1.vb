﻿Public Class Form1

    Function IsPrime(intCheckNumber As Integer) As Boolean
        Dim intCounter As Integer = 0
        Dim intI As Integer
        Integer.TryParse(txtInput.Text, intCheckNumber)

        If intCheckNumber = 1 Or intCheckNumber = 2 Then
            Return True
        End If

        For intI = 2 To intCheckNumber - 1
            If intCheckNumber Mod intI = 0 Then
                Return False
            End If
        Next
        Return True
    End Function
    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        If IsPrime(5) Then
            MessageBox.Show("Number is Prime.")
        Else
            MessageBox.Show("Number is not Prime")
        End If

        txtInput.Text = String.Empty
        txtInput.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
