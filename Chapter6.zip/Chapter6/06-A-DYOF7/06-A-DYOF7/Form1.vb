﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intCount As Integer = 1
        Dim decTotalCost As Decimal = 0D
        Dim intNumRooms As Integer
        Dim decGallonofPaint As Decimal
        Dim intAmountofPaint As Integer
        Dim dblLabor As Double
        Dim intSquareFeet As Integer
        Dim strInput As String

        Try

            strInput = InputBox("How many rooms do you need painted?")

            intNumRooms = CInt(strInput)

            strInput = InputBox("How much per gallon of paint?")
            decGallonofPaint = CDec(strInput)

            If intNumRooms < 1 Then
                MessageBox.Show("Rooms must be greater than 1.")
            End If

            If decGallonofPaint < 10D Then
                MessageBox.Show("Gallon of paint must be $10 or greater value.")
            End If

            If intSquareFeet < 1 Then
                MessageBox.Show("Please enter a numeric value for the square feet.")
            End If

            Do While intCount <= intNumRooms
                strInput = InputBox("Enter the square feet of wall in room " &
                                    intCount.ToString() & ".")

                Try
                    intSquareFeet += CInt(strInput)

                    intCount += 1
                Catch
                    MessageBox.Show("The amount listed is not valid.")
                End Try
            Loop
            dblLabor = (intSquareFeet / 115) * 8
            intAmountofPaint = CInt(Math.Ceiling(intSquareFeet / 115))

            lblGallonsRequired.Text = intAmountofPaint.ToString()
            lblLaborHours.Text = dblLabor.ToString()
            lblCostofPaint.Text = decGallonofPaint.ToString("C")
            lblLaborCharges.Text = (dblLabor * 18D).ToString("C")
            lblTotalCost.Text = ((intAmountofPaint * decGallonofPaint) + (dblLabor * 18D)).ToString("C")
        Catch
            MessageBox.Show("The number of days is not valid.")
        End Try
    End Sub
End Class
