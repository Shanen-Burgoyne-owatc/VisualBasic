﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblGallonsRequired = New System.Windows.Forms.Label()
        Me.lblLaborHours = New System.Windows.Forms.Label()
        Me.lblCostofPaint = New System.Windows.Forms.Label()
        Me.lblLaborCharges = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(74, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(192, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Number of Gallons Required:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(159, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Hours of Labor:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(174, 212)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Cost of Paint:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(160, 306)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Labor Charges:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(115, 384)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Total Cost of Pain Job:"
        '
        'lblGallonsRequired
        '
        Me.lblGallonsRequired.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGallonsRequired.Location = New System.Drawing.Point(303, 47)
        Me.lblGallonsRequired.Name = "lblGallonsRequired"
        Me.lblGallonsRequired.Size = New System.Drawing.Size(78, 17)
        Me.lblGallonsRequired.TabIndex = 5
        '
        'lblLaborHours
        '
        Me.lblLaborHours.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLaborHours.Location = New System.Drawing.Point(303, 126)
        Me.lblLaborHours.Name = "lblLaborHours"
        Me.lblLaborHours.Size = New System.Drawing.Size(78, 17)
        Me.lblLaborHours.TabIndex = 6
        '
        'lblCostofPaint
        '
        Me.lblCostofPaint.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCostofPaint.Location = New System.Drawing.Point(303, 212)
        Me.lblCostofPaint.Name = "lblCostofPaint"
        Me.lblCostofPaint.Size = New System.Drawing.Size(78, 17)
        Me.lblCostofPaint.TabIndex = 7
        '
        'lblLaborCharges
        '
        Me.lblLaborCharges.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLaborCharges.Location = New System.Drawing.Point(303, 306)
        Me.lblLaborCharges.Name = "lblLaborCharges"
        Me.lblLaborCharges.Size = New System.Drawing.Size(78, 17)
        Me.lblLaborCharges.TabIndex = 8
        '
        'lblTotalCost
        '
        Me.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCost.Location = New System.Drawing.Point(303, 384)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(78, 17)
        Me.lblTotalCost.TabIndex = 9
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(55, 484)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(143, 43)
        Me.btnCalculate.TabIndex = 10
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(499, 579)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.lblLaborCharges)
        Me.Controls.Add(Me.lblCostofPaint)
        Me.Controls.Add(Me.lblLaborHours)
        Me.Controls.Add(Me.lblGallonsRequired)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Paint Estimator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblGallonsRequired As Label
    Friend WithEvents lblLaborHours As Label
    Friend WithEvents lblCostofPaint As Label
    Friend WithEvents lblLaborCharges As Label
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents btnCalculate As Button
End Class
