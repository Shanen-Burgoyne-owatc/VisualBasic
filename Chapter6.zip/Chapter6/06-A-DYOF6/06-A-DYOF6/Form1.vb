﻿Public Class Form1
    Private decMeals As Decimal
    Private decAirfare As Decimal
    Private intDays As Integer
    Private intMiles As Integer
    Private decParking As Decimal
    Private decTaxi As Decimal
    Private decLodging As Decimal
    Private decRegistration As Decimal
    Private decCarRental As Decimal

    Function ValidateInput() As Boolean
        If Not Decimal.TryParse(txtMeals.Text, decMeals) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        If Not Decimal.TryParse(txtAirfare.Text, decAirfare) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        If Not Decimal.TryParse(txtParkingFees.Text, decParking) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        If Not Decimal.TryParse(txtTaxiCharges.Text, decTaxi) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        If Not Decimal.TryParse(txtLodging.Text, decLodging) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        If Not Decimal.TryParse(txtCarRental.Text, decCarRental) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        If Not Decimal.TryParse(txtConference.Text, decRegistration) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        If Not Integer.TryParse(txtDays.Text, intDays) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        If Not Integer.TryParse(txtMilesDriven.Text, intMiles) Then
            MessageBox.Show("Please enter a valid entry")
            Return False
        End If

        Return True
    End Function

    Function CalcMeals() As Decimal
        Dim decMeals As Decimal
        Decimal.TryParse(txtMeals.Text, decMeals)

        Return decMeals
    End Function

    Function CalcMileage() As Decimal
        Dim intMilesDriven As Integer
        Integer.TryParse(txtMilesDriven.Text, intMilesDriven)

        Return intMilesDriven * 0.27D
    End Function

    Function CalcParkingFees() As Decimal
        Dim decParking_Fees As Decimal
        Decimal.TryParse(txtParkingFees.Text, decParking_Fees)
        If decParking_Fees < 10D Then
            Return decParking_Fees
        Else
            Return 10D
        End If

    End Function

    Function CalcTaxiFees() As Decimal
        Dim decTaxi_Fees As Decimal
        Decimal.TryParse(txtTaxiCharges.Text, decTaxi_Fees)
        If decTaxi_Fees < 20D Then
            Return decTaxi_Fees
        Else
            Return 20D
        End If

    End Function

    Function CalcLodging() As Decimal
        Dim decLodging As Decimal
        Decimal.TryParse(txtLodging.Text, decLodging)
        If decLodging < 95D Then
            Return decLodging
        Else
            Return 95D
        End If

    End Function

    Function CalcTotalReimbursement() As Decimal
        Dim decReimbursement As Decimal = 0D
        decReimbursement = CalcMeals() + CalcMileage() + CalcParkingFees() + CalcTaxiFees() + CalcLodging()

        Return decReimbursement
    End Function

    Function CalcUnallowed() As Decimal
        Dim decUnallowed As Decimal = 0D
        Dim decCalculations As Decimal

        Decimal.TryParse(txtMeals.Text, decCalculations)
        If decCalculations > 37D Then
            decUnallowed += decCalculations - 37D
        End If

        Decimal.TryParse(txtParkingFees.Text, decCalculations)
        If decCalculations > 10D Then
            decUnallowed += decCalculations - 10D
        End If

        Decimal.TryParse(txtTaxiCharges.Text, decCalculations)
        If decCalculations > 20D Then
            decUnallowed += decCalculations - 20D
        End If

        Decimal.TryParse(txtLodging.Text, decCalculations)
        If decCalculations > 95D Then
            decUnallowed += decCalculations - 95D
        End If

        Return decUnallowed
    End Function

    Function CalcSaved() As Decimal
        Dim decSaved As Decimal = 0D
        Dim decCalculations As Decimal

        Decimal.TryParse(txtMeals.Text, decCalculations)
        If decCalculations < 37D Then
            decSaved += 37D - decCalculations
        End If

        Decimal.TryParse(txtParkingFees.Text, decCalculations)
        If decCalculations < 10D Then
            decSaved += 10D - decCalculations
        End If

        Decimal.TryParse(txtTaxiCharges.Text, decCalculations)
        If decCalculations < 20D Then
            decSaved += 20D - decCalculations
        End If

        Decimal.TryParse(txtLodging.Text, decCalculations)
        If decCalculations < 95D Then
            decSaved += 95D - decCalculations
        End If

        Return decSaved
    End Function

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim intdays As Integer
        Dim decCarRental As Decimal
        Dim decRegistration As Decimal
        Dim decAirfare As Decimal
        Dim decTotalIncurred As Decimal = 0D

        ValidateInput()

        Integer.TryParse(txtDays.Text, intdays)
        Decimal.TryParse(txtAirfare.Text, decAirfare)
        Decimal.TryParse(txtCarRental.Text, decCarRental)
        Decimal.TryParse(txtConference.Text, decRegistration)

        decTotalIncurred = decAirfare + decCarRental + decRegistration + (CalcMeals() * intdays) +
            (CalcLodging() * intdays) + CalcMileage() + (CalcParkingFees() * intdays) +
            (CalcTaxiFees() * intdays)


        lblTotalIncurred.Text = decTotalIncurred.ToString("C")
        lblAllowableExpenses.Text = CalcTotalReimbursement().ToString("C")
        lblExcessExpenses.Text = CalcUnallowed().ToString("C")
        lblSaved.Text = CalcSaved().ToString("C")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtDays.Text = String.Empty
        txtAirfare.Text = String.Empty
        txtMeals.Text = String.Empty
        txtCarRental.Text = String.Empty
        txtMilesDriven.Text = String.Empty
        txtParkingFees.Text = String.Empty
        txtTaxiCharges.Text = String.Empty
        txtConference.Text = String.Empty
        txtLodging.Text = String.Empty

        lblTotalIncurred.Text = String.Empty
        lblExcessExpenses.Text = String.Empty
        lblAllowableExpenses.Text = String.Empty
        lblSaved.Text = String.Empty

        txtDays.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
