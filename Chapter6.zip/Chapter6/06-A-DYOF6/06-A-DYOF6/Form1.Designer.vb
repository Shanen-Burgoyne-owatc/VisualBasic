﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtDays = New System.Windows.Forms.TextBox()
        Me.txtAirfare = New System.Windows.Forms.TextBox()
        Me.txtMeals = New System.Windows.Forms.TextBox()
        Me.txtCarRental = New System.Windows.Forms.TextBox()
        Me.txtMilesDriven = New System.Windows.Forms.TextBox()
        Me.txtParkingFees = New System.Windows.Forms.TextBox()
        Me.txtTaxiCharges = New System.Windows.Forms.TextBox()
        Me.txtConference = New System.Windows.Forms.TextBox()
        Me.txtLodging = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblTotalIncurred = New System.Windows.Forms.Label()
        Me.lblAllowableExpenses = New System.Windows.Forms.Label()
        Me.lblExcessExpenses = New System.Windows.Forms.Label()
        Me.lblSaved = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(221, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(159, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Travel Expenses"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(52, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(193, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Number of Days on Trip:"
        '
        'txtDays
        '
        Me.txtDays.Location = New System.Drawing.Point(342, 62)
        Me.txtDays.Multiline = True
        Me.txtDays.Name = "txtDays"
        Me.txtDays.Size = New System.Drawing.Size(99, 20)
        Me.txtDays.TabIndex = 2
        Me.txtDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAirfare
        '
        Me.txtAirfare.Location = New System.Drawing.Point(342, 106)
        Me.txtAirfare.Multiline = True
        Me.txtAirfare.Name = "txtAirfare"
        Me.txtAirfare.Size = New System.Drawing.Size(99, 20)
        Me.txtAirfare.TabIndex = 3
        Me.txtAirfare.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtMeals
        '
        Me.txtMeals.Location = New System.Drawing.Point(342, 143)
        Me.txtMeals.Multiline = True
        Me.txtMeals.Name = "txtMeals"
        Me.txtMeals.Size = New System.Drawing.Size(99, 20)
        Me.txtMeals.TabIndex = 4
        Me.txtMeals.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCarRental
        '
        Me.txtCarRental.Location = New System.Drawing.Point(342, 183)
        Me.txtCarRental.Multiline = True
        Me.txtCarRental.Name = "txtCarRental"
        Me.txtCarRental.Size = New System.Drawing.Size(99, 20)
        Me.txtCarRental.TabIndex = 5
        Me.txtCarRental.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtMilesDriven
        '
        Me.txtMilesDriven.Location = New System.Drawing.Point(342, 224)
        Me.txtMilesDriven.Multiline = True
        Me.txtMilesDriven.Name = "txtMilesDriven"
        Me.txtMilesDriven.Size = New System.Drawing.Size(99, 20)
        Me.txtMilesDriven.TabIndex = 6
        Me.txtMilesDriven.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtParkingFees
        '
        Me.txtParkingFees.Location = New System.Drawing.Point(342, 262)
        Me.txtParkingFees.Multiline = True
        Me.txtParkingFees.Name = "txtParkingFees"
        Me.txtParkingFees.Size = New System.Drawing.Size(99, 20)
        Me.txtParkingFees.TabIndex = 7
        Me.txtParkingFees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTaxiCharges
        '
        Me.txtTaxiCharges.Location = New System.Drawing.Point(342, 307)
        Me.txtTaxiCharges.Multiline = True
        Me.txtTaxiCharges.Name = "txtTaxiCharges"
        Me.txtTaxiCharges.Size = New System.Drawing.Size(99, 20)
        Me.txtTaxiCharges.TabIndex = 8
        Me.txtTaxiCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtConference
        '
        Me.txtConference.Location = New System.Drawing.Point(342, 346)
        Me.txtConference.Multiline = True
        Me.txtConference.Name = "txtConference"
        Me.txtConference.Size = New System.Drawing.Size(99, 20)
        Me.txtConference.TabIndex = 9
        Me.txtConference.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtLodging
        '
        Me.txtLodging.Location = New System.Drawing.Point(342, 384)
        Me.txtLodging.Multiline = True
        Me.txtLodging.Name = "txtLodging"
        Me.txtLodging.Size = New System.Drawing.Size(99, 20)
        Me.txtLodging.TabIndex = 10
        Me.txtLodging.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(141, 106)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 20)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Airfare Cost:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(186, 143)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 20)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Meals:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(109, 183)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 20)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Car Rental Fees:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 224)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(237, 20)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Miles Driven (For private Car):"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(133, 262)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(112, 20)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Parking Fees:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(132, 307)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 20)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Taxi Charges:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(52, 346)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(195, 20)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Conference Registration:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(118, 384)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(127, 20)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Lodging / Night:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(69, 559)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(125, 47)
        Me.btnCalculate.TabIndex = 19
        Me.btnCalculate.Text = "Calculate Expenses"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lblTotalIncurred
        '
        Me.lblTotalIncurred.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalIncurred.Location = New System.Drawing.Point(12, 487)
        Me.lblTotalIncurred.Name = "lblTotalIncurred"
        Me.lblTotalIncurred.Size = New System.Drawing.Size(99, 23)
        Me.lblTotalIncurred.TabIndex = 20
        '
        'lblAllowableExpenses
        '
        Me.lblAllowableExpenses.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAllowableExpenses.Location = New System.Drawing.Point(164, 487)
        Me.lblAllowableExpenses.Name = "lblAllowableExpenses"
        Me.lblAllowableExpenses.Size = New System.Drawing.Size(99, 23)
        Me.lblAllowableExpenses.TabIndex = 21
        '
        'lblExcessExpenses
        '
        Me.lblExcessExpenses.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExcessExpenses.Location = New System.Drawing.Point(314, 487)
        Me.lblExcessExpenses.Name = "lblExcessExpenses"
        Me.lblExcessExpenses.Size = New System.Drawing.Size(99, 23)
        Me.lblExcessExpenses.TabIndex = 22
        '
        'lblSaved
        '
        Me.lblSaved.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSaved.Location = New System.Drawing.Point(460, 487)
        Me.lblSaved.Name = "lblSaved"
        Me.lblSaved.Size = New System.Drawing.Size(99, 23)
        Me.lblSaved.TabIndex = 23
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(226, 559)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(125, 47)
        Me.btnReset.TabIndex = 24
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(383, 559)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(125, 47)
        Me.btnExit.TabIndex = 25
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(30, 435)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(60, 34)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Total" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Incurred"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(187, 435)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(69, 34)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "Allowed" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Expenses"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(330, 435)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(69, 34)
        Me.Label13.TabIndex = 28
        Me.Label13.Text = "Excess" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Expenses"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(485, 435)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(56, 34)
        Me.Label14.TabIndex = 29
        Me.Label14.Text = "Amount" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Saved"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(601, 658)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.lblSaved)
        Me.Controls.Add(Me.lblExcessExpenses)
        Me.Controls.Add(Me.lblAllowableExpenses)
        Me.Controls.Add(Me.lblTotalIncurred)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtLodging)
        Me.Controls.Add(Me.txtConference)
        Me.Controls.Add(Me.txtTaxiCharges)
        Me.Controls.Add(Me.txtParkingFees)
        Me.Controls.Add(Me.txtMilesDriven)
        Me.Controls.Add(Me.txtCarRental)
        Me.Controls.Add(Me.txtMeals)
        Me.Controls.Add(Me.txtAirfare)
        Me.Controls.Add(Me.txtDays)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Travel Expenses"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtDays As TextBox
    Friend WithEvents txtAirfare As TextBox
    Friend WithEvents txtMeals As TextBox
    Friend WithEvents txtCarRental As TextBox
    Friend WithEvents txtMilesDriven As TextBox
    Friend WithEvents txtParkingFees As TextBox
    Friend WithEvents txtTaxiCharges As TextBox
    Friend WithEvents txtConference As TextBox
    Friend WithEvents txtLodging As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblTotalIncurred As Label
    Friend WithEvents lblAllowableExpenses As Label
    Friend WithEvents lblExcessExpenses As Label
    Friend WithEvents lblSaved As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
End Class
