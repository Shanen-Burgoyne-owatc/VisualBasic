﻿Imports Microsoft.VisualBasic.FileIO
Imports System.Collections.Generic

Public Class Form1
    Dim inventoryList As New List(Of Inventory)
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadFile("inventory.txt")
        lstItems.DataSource = inventoryList
    End Sub

    Public Sub LoadFile(fileName As String)
        Dim fs As New TextFieldParser(fileName)
        fs.SetDelimiters(",")
        While Not fs.EndOfData
            Dim value As String()
            value = fs.ReadFields()
            Dim invItem As New Inventory()
            invItem.InvNum = value(0)
            invItem.Description = value(1)
            invItem.Cost = CDec(value(2))
            invItem.Retail = CDec(value(3))
            invItem.OnHand = CInt(value(4))
            inventoryList.Add(invItem)
        End While
    End Sub

    Public Sub lstItems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstItems.SelectedIndexChanged
        If lstItems.SelectedIndex = -1 Then
            Return
        End If
        UpdateDetailsList()

    End Sub

    Private Sub UpdateDetailsList()
        Dim inv As Inventory
        inv = CType(lstItems.SelectedItem, Inventory)
        lblDescription.Text = inv.Description
        lblPrice.Text = inv.Cost.ToString("C")
        lblUnits.Text = CType(inv.OnHand, String)
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim Quantity As Integer
        Dim total As Double
        If lstItems.SelectedIndex = -1 Then
            Return
        End If
        Dim inv As Inventory
        inv = CType(lstItems.SelectedItem, Inventory)

        Quantity = CInt(txtQuantity.Text)
        If Quantity <= inv.OnHand Then
            Dim salesTax = (inv.Cost * Quantity) * 0.07
            lblSalesTax.Text = salesTax.ToString("C")
            inv.OnHand -= Quantity
            total = salesTax + (inv.Cost * Quantity)
            lblTotal.Text = total.ToString("C")
            UpdateDetailsList()

        Else
            MsgBox("Cannot purchase more than on hand amount.")
        End If



    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim sb As New Text.StringBuilder
        For Each item In inventoryList
            sb.AppendLine(
                item.InvNum + "," +
                item.Description + "," +
                item.Cost.ToString() + "," +
                item.Retail.ToString() + "," +
                item.OnHand.ToString())
        Next
        IO.File.WriteAllText("inventory2.txt", sb.ToString())
        Me.Close()
    End Sub
End Class
