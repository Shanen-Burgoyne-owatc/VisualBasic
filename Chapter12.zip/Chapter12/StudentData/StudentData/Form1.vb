﻿Imports System.IO

Public Class Form1

    ' The GetFata procedure gets data from teh text boxes
    ' and stores it in the object referenced by the objStudent.
    Private Sub GetData(ByVal objStudent As Student)
        Try
            ' Assign values from the form to the object properties.
            objStudent.LastName = txtLastName.Text
            objStudent.FirstName = txtFirstName.Text
            objStudent.IdNumber = txtIdNumber.Text
            objStudent.TestAverage = CDbl(txtTestAverage.Text)
        Catch ex As Exception
            ' Display an error message.
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SaveRecord(ByVal objStudent As Student)
        Dim writer As StreamWriter

        Try
            ' open the file in Append mode.
            writer = File.AppendText("Students.txt")

            ' Save the Student object's properties.
            writer.WriteLine(objStudent.IdNumber)
            writer.WriteLine(objStudent.FirstName)
            writer.WriteLine(objStudent.LastName)
            writer.WriteLine(objStudent.TestAverage.ToString())
            writer.WriteLine(objStudent.Grade)

            ' Close the StreamWriter.
            writer.Close()
        Catch ex As Exception
            ' Display an error message.
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ' The ClearForm procedure clears the form.
    Private Sub ClearForm()
        'Clear the text boxes
        txtFirstName.Clear()
        txtLastName.Clear()
        txtIdNumber.Clear()
        txtTestAverage.Clear()
        lblGrade.Text = String.Empty

        ' Reset the focus
        txtLastName.Focus()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        ' Create an instance of the Student class.
        Dim objStudent As New Student

        ' Get data from the form.
        GetData(objStudent)

        ' Display the student's record.
        lblGrade.Text = objStudent.Grade

        ' Save this student's record.
        SaveRecord(objStudent)

        ' Confirm that the record was saved.
        MessageBox.Show("Student record saved")

        ' Clear the form.
        ClearForm()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Close the form.
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Enable output to the Output window.
        Debug.Listeners.Add(New ConsoleTraceListener())
    End Sub
End Class