﻿Public Class Rectangle
    Public Width As Double
    Public Length As Double
    Public Area As Double

    Public Sub CalcArea()
        Area = Length * Width
    End Sub
End Class
