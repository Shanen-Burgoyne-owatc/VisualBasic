﻿Public Class Carpet
    Public Color As String
    Public Style As String
    Public Price As Double
End Class
