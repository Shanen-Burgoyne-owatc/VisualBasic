﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim rect = New Rectangle()
        Dim carp = New Carpet()

        rect.Width = CDbl(txtWidth.Text)
        rect.Length = CDbl(txtLength.Text)
        rect.CalcArea()
        lblArea.Text = CStr(rect.Area)

        carp.Color = txtColor.Text
        carp.Style = txtStyle.Text
        carp.Price = CDbl(txtSqFt.Text)

        lblTotal.Text = CStr(rect.Area * carp.Price)
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblArea.Text = String.Empty
        lblTotal.Text = String.Empty

        txtColor.Clear()
        txtSqFt.Clear()
        txtLength.Clear()
        txtWidth.Clear()
        txtStyle.Clear()

        txtColor.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
