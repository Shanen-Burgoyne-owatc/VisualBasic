﻿Option Strict Off
Imports System.IO


Public Class Form1
    Dim InvItems As New Collection
    Dim dataFile As StreamReader
    Dim inputfile As StreamWriter

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            inputfile = File.AppendText("invetory.txt")

            Dim item As New Inventory
            item.InvNum = txtInvNumber.Text
            item.Description = txtDescription.Text
            item.Cost = txtCost.Text
            item.Retail = CDec(txtRetailPrice.Text)
            item.OnHand = CInt(txtOnHand.Text)

            InvItems.Add(item)
            inputfile.WriteLine(item.InvNum.ToString())
            inputfile.WriteLine(item.Description.ToString())
            inputfile.WriteLine(item.Cost.ToString())
            inputfile.WriteLine(item.Retail.ToString())
            inputfile.WriteLine(item.OnHand.ToString())
            inputfile.Close()
            MessageBox.Show("Item successfully added to the
collection", "Done")
            ClearFields()
        Catch ex As Exception
            MessageBox.Show("Enter all fields", "Warning")
        End Try
    End Sub

    Public Sub ClearFields()
        txtCost.Clear()
        txtDescription.Clear()
        txtInvNumber.Clear()
        txtOnHand.Clear()
        txtRetailPrice.Clear()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        If txtInvNumber.Text = "" Then
            MessageBox.Show("Please enter item number in the first text box.", "Warning")
        Else
            Dim num As String = txtInvNumber.Text
            Dim item As Inventory
            Dim found As Boolean = False

            For index = 1 To InvItems.Count
                item = InvItems(index)
                If num = item.InvNum Then
                    txtDescription.Text = item.Description
                    txtCost.Text = FormatCurrency(item.Cost, 2)
                    txtRetailPrice.Text = FormatCurrency(item.Retail, 2)
                    txtOnHand.Text = item.OnHand.ToString()
                    found = True
                    Exit For
                End If
            Next
            If found = False Then
                MessageBox.Show("No item is found with this number", "No Item Found")
            End If
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            dataFile = File.OpenText("inventory.txt")

            While Not dataFile.EndOfStream
                Dim item As New Inventory
                item.InvNum = dataFile.ReadLine()
                item.Description = dataFile.ReadLine()
                item.Cost = CDec(dataFile.ReadLine())
                item.Retail = CDec(dataFile.ReadLine())
                item.OnHand = CInt(dataFile.ReadLine())
                InvItems.Add(item)
            End While
        Catch ex As Exception
            If ex.InnerException.ToString().Equals("System.IO.FileNotFound Exception") Then
                File.CreateText("inventory.txt")
            End If
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub
End Class
