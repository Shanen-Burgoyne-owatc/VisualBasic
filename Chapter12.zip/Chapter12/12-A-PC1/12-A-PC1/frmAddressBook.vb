﻿Option Strict Off
Public Class frmAddressBook
    Public AddressList As New Collection

    Private Sub UpdateListBox()

        lstNames.Items.Clear()

        Dim a As address
        For Each a In AddressList
            lstNames.Items.Add(a.Name)
        Next
        If lstNames.Items.Count > 0 Then
            lstNames.SelectedIndex = 0
        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        frmAddNew.ClearForm()
        frmAddNew.ShowDialog()

        Try
            AddressList.Add(frmAddNew.objStudent, frmAddNew.objStudent.Name)
        Catch ex As Exception
        End Try
        UpdateListBox()
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        Dim intIndex As Integer

        If lstNames.SelectedIndex <> -1 Then
            If MessageBox.Show("Are you sure?", "Confirm deletion", MessageBoxButtons.YesNo) =
                    Windows.Forms.DialogResult.Yes Then

                intIndex = lstNames.SelectedIndex

                Try
                    AddressList.Remove(lstNames.SelectedItem.ToString())
                    UpdateListBox()
                Catch ex As Exception
                    ' Error message
                    MessageBox.Show(ex.Message)
                End Try
            End If
        End If
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If lstNames.SelectedIndex <> -1 Then
            Dim st As New address
            st = AddressList.Item(lstNames.SelectedItem.ToString())
            frmAddNew.txtName.Text = st.Name
            frmAddNew.txtEmail.Text = st.EMail
            frmAddNew.txtPhone.Text = st.Phone
            frmAddNew.rtbNotes.Text = st.Comments
            frmAddNew.ShowDialog()

            AddressList.Remove(st.Name)
            AddressList.Add(frmAddNew.objStudent, frmAddNew.objStudent.Name)
            UpdateListBox()
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
