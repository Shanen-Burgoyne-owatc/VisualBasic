﻿Public Class frmAddNew
    Public objStudent As New address

    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        objStudent.Name = txtName.Text
        objStudent.Phone = txtPhone.Text
        objStudent.EMail = txtEmail.Text
        objStudent.Comments = rtbNotes.Text

        ClearForm()
        Me.Close()
    End Sub

    Public Sub ClearForm()
        txtEmail.Clear()
        txtName.Clear()
        txtPhone.Clear()
        rtbNotes.Clear()

        txtName.Focus()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class