﻿Public Class address
    Private personName As String
    Private personEmail As String
    Private personPhone As String
    Private personComments As String

    Public Property Name As String
        Get
            Return personName
        End Get
        Set(value As String)
            personName = value
        End Set
    End Property

    Public Property EMail As String
        Get
            Return personEmail
        End Get
        Set(value As String)
            personEmail = value
        End Set
    End Property

    Public Property Phone As String
        Get
            Return personPhone
        End Get
        Set(value As String)
            personPhone = value
        End Set
    End Property

    Public Property Comments As String
        Get
            Return personComments
        End Get
        Set(value As String)
            personComments = value
        End Set
    End Property
End Class
