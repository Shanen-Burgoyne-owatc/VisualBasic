﻿Option Strict Off
Public Class Form1
    Dim InvItems As New Collection
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            Dim item As New Inventory
            item.InvNum = txtInvNumber.Text
            item.Description = txtDescription.Text
            item.Cost = CDec(txtCost.Text)
            item.retail = CDec(txtRetailPrice.Text)
            item.OnHand = CInt(txtOnHand.Text)

            InvItems.Add(item)
            MessageBox.Show("Item successfully added to the collection", "Done")
            ClearFields()
        Catch ex As Exception
            MessageBox.Show("Enter all fields", "Warning")
        End Try
    End Sub

    Public Sub ClearFields()
        txtCost.Clear()
        txtDescription.Clear()
        txtInvNumber.Clear()
        txtOnHand.Clear()
        txtRetailPrice.Clear()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        If txtInvNumber.Text = "" Then
            MessageBox.Show("Please enter item number in the first text box.",
                            "Warning")
        Else
            Dim num As String = txtInvNumber.Text
            Dim item As Inventory
            Dim found As Boolean = False

            For index = 1 To InvItems.Count
                item = InvItems(index)
                If num = item.InvNum Then
                    txtDescription.Text = item.Description
                    txtCost.Text = FormatCurrency(item.Cost, 2)
                    txtRetailPrice.Text = FormatCurrency(item.retail, 2)
                    txtOnHand.Text = item.OnHand.ToString()
                    found = True
                End If
            Next
            If found = False Then
                MessageBox.Show("No item is found with this number", "No Item Found")
            End If
        End If
    End Sub
End Class
