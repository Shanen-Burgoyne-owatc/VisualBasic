﻿Public Class Inventory
    Private m_invnum As String
    Private m_descr As String
    Private m_cost As Decimal
    Private m_retail As Decimal
    Private m_onhand As Integer

    Public Property InvNum() As String
        Get
            Return m_invnum
        End Get
        Set(value As String)
            m_invnum = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return m_descr
        End Get
        Set(value As String)
            m_descr = value
        End Set
    End Property

    Public Property Cost() As Decimal
        Get
            Return m_cost
        End Get
        Set(value As Decimal)
            m_cost = value
        End Set
    End Property

    Public Property retail() As Decimal
        Get
            Return m_retail
        End Get
        Set(value As Decimal)
            m_retail = value
        End Set
    End Property

    Public Property OnHand() As Integer
        Get
            Return m_onhand
        End Get
        Set(value As Integer)
            If value > 0 Then
                m_onhand = value
            Else
                m_onhand = 0
            End If
        End Set
    End Property
End Class
