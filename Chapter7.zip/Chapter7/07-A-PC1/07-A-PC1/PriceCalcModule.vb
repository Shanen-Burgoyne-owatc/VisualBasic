﻿Module PriceCalcModule
    ' Global total

    Public decTotal As Decimal = 0

End Module
