﻿Public Class ConferenceOptions
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        decTotal = 0

        If chkRegistration.Checked = True Then
            decTotal += 895D
        End If

        If chkDinner.Checked = True Then
            decTotal += 30D
        End If

        If lstPreconference.SelectedIndex = 0 Then
            decTotal += 295D
        End If

        If lstPreconference.SelectedIndex = 1 Then
            decTotal += 295D
        End If

        If lstPreconference.SelectedIndex = 2 Then
            decTotal += 395D
        End If

        If lstPreconference.SelectedIndex = 3 Then
            decTotal += 395D
        End If

        Me.Close()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        chkRegistration.Checked = False
        chkDinner.Checked = False

        lstPreconference.ClearSelected()
    End Sub

    Private Sub chkRegistration_CheckedChanged(sender As Object, e As EventArgs) Handles chkRegistration.CheckedChanged
        If chkRegistration.Checked = True Then
            lstPreconference.Enabled = True
        Else
            lstPreconference.Enabled = False
            lstPreconference.ClearSelected()
        End If
    End Sub
End Class