﻿Public Class Form1
    Private Sub btnConferenceOptions_Click(sender As Object, e As EventArgs) Handles btnConferenceOptions.Click
        Dim frmOptions As New ConferenceOptions

        frmOptions.ShowDialog()

        lblTotal.Text = decTotal.ToString("C")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtName.Text = String.Empty
        txtAddress.Text = String.Empty
        txtCity.Text = String.Empty
        txtCompany.Text = String.Empty
        txtEmail.Text = String.Empty
        txtPhone.Text = String.Empty
        txtState.Text = String.Empty
        txtZip.Text = String.Empty
        lblTotal.Text = String.Empty

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
