﻿Module BookCalculationsModule

    Public Const decPrintYourWay As Decimal = 11.95D
    Public Const decPrintScotland As Decimal = 14.5D
    Public Const decPrintCalculus As Decimal = 29.95D
    Public Const decPrintStress As Decimal = 18.5D

    Public Const decAudioCalculus As Decimal = 29.95D
    Public Const decAudioScotland As Decimal = 14.5D
    Public Const decAudioBodyLanguage As Decimal = 12.95D
    Public Const decAudioRelaxationTech As Decimal = 11.5D

    Public decTotal As Decimal = 0
    Public decSubtotal As Decimal = 0
    Public decShipping As Decimal = 2D
    Public decShippingTotal As Decimal = 0
    Public decTax As Decimal = 0.06D
    Public decTotalTax As Decimal = 0
    Public MainForm As New MainForm()
End Module
