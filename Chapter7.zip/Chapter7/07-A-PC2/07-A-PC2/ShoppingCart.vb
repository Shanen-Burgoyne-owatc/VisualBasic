﻿Public Class MainForm

    Private Sub mnuProductsPrint_Click(sender As Object, e As EventArgs) Handles mnuProductsPrint.Click
        Dim PrintBooks As New PrintBooks
        PrintBooks.ShowDialog()

        lblSubtotal.Text = decSubtotal.ToString("C")
        lblShipping.Text = decShippingTotal.ToString("C")
    End Sub

    Private Sub mnuProductsAudio_Click(sender As Object, e As EventArgs) Handles mnuProductsAudio.Click
        Dim AudioBooks As New AudioBooks
        AudioBooks.ShowDialog()

        lblSubtotal.Text = decSubtotal.ToString("C")
    End Sub

    Public Sub ShippingCalculations()
        decShippingTotal = (decShipping * lstSelectedProducts.Items.Count())
        lblShipping.Text = decShippingTotal.ToString("C")
    End Sub

    Public Sub Total()
        decTotal = (decSubtotal + decShippingTotal)
        lblTotal.Text = decTotal.ToString("C")
    End Sub

    Public Sub Tax()

        lblTax.Text = (decTotal * decTax).ToString("C")
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If lstSelectedProducts.SelectedItem Is Nothing Then
            Return
        End If

        If lstSelectedProducts.SelectedItem.ToString() = "Learn Calculus in One Day (Audio)" Then
            lstSelectedProducts.Items.Remove("Learn Calculus in One Day (Audio)")
            decSubtotal -= decAudioCalculus
            lblSubtotal.Text = decSubtotal.ToString("C")
            decTotalTax -= decAudioCalculus * decTax
            lblTax.Text = decTotalTax.ToString("C")
            ShippingCalculations()
            decTotal -= decAudioCalculus + decShipping + (decAudioCalculus * decTax)
            lblTotal.Text = decTotal.ToString("C")

        ElseIf lstSelectedProducts.SelectedItem.ToString() = "The History of Scotland (Audio)" Then
            lstSelectedProducts.Items.Remove("The History of Scotland (Audio)")
            decSubtotal -= decAudioScotland
            lblSubtotal.Text = decSubtotal.ToString("C")
            decTotalTax -= decAudioScotland * decTax
            lblTax.Text = decTotalTax.ToString("C")
            ShippingCalculations()
            decTotal -= decAudioScotland + decShipping + (decAudioScotland * decTax)
            lblTotal.Text = decTotal.ToString("C")

        ElseIf lstSelectedProducts.SelectedItem.ToString() = "The Science of Body Language (Audio)" Then
            lstSelectedProducts.Items.Remove("The Science of Body Language (Audio)")
            decSubtotal -= decAudioBodyLanguage
            lblSubtotal.Text = decSubtotal.ToString("C")
            decTotalTax -= decAudioBodyLanguage * decTax
            lblTax.Text = decTotalTax.ToString("C")
            ShippingCalculations()
            decTotal -= decAudioBodyLanguage + decShipping + (decAudioBodyLanguage * decTax)
            lblTotal.Text = decTotal.ToString("C")

        ElseIf lstSelectedProducts.SelectedItem.ToString() = "Relaxation Techniques (Audio)" Then
            lstSelectedProducts.Items.Remove("Relaxation Techniques (Audio)")
            decSubtotal -= decAudioRelaxationTech
            lblSubtotal.Text = decSubtotal.ToString("C")
            decTotalTax -= decAudioRelaxationTech * decTax
            lblTax.Text = decTotalTax.ToString("C")
            ShippingCalculations()
            decTotal -= decAudioRelaxationTech + decShipping + (decAudioRelaxationTech * decTax)
            lblTotal.Text = decTotal.ToString("C")

        ElseIf lstSelectedProducts.SelectedItem.ToString() = "I Did It Your Way (Print)" Then
            lstSelectedProducts.Items.Remove("I Did It Your Way (Print)")
            decSubtotal -= decPrintYourWay
            lblSubtotal.Text = decSubtotal.ToString("C")
            decTotalTax -= decPrintYourWay * decTax
            lblTax.Text = decTotalTax.ToString("C")
            ShippingCalculations()
            decTotal -= decPrintYourWay + decShipping + (decPrintYourWay * decTax)
            lblTotal.Text = decTotal.ToString("C")

        ElseIf lstSelectedProducts.SelectedItem.ToString() = "The History of Scotland (Print)" Then
            lstSelectedProducts.Items.Remove("The History of Scotland (Print)")
            decSubtotal -= decPrintScotland
            lblSubtotal.Text = decSubtotal.ToString("C")
            decTotalTax -= decPrintScotland * decTax
            lblTax.Text = decTotalTax.ToString("C")
            ShippingCalculations()
            decTotal -= decPrintScotland + decShipping + (decPrintScotland * decTax)
            lblTotal.Text = decTotal.ToString("C")

        ElseIf lstSelectedProducts.SelectedItem.ToString() = "Learn Calculus in One Day (Print)" Then
            lstSelectedProducts.Items.Remove("Learn Calculus in One Day (Print)")
            decSubtotal -= decPrintCalculus
            lblSubtotal.Text = decSubtotal.ToString("C")
            decTotalTax -= decPrintCalculus * decTax
            lblTax.Text = decTotalTax.ToString("C")
            ShippingCalculations()
            decTotal -= decPrintCalculus + decShipping + (decPrintCalculus * decTax)
            lblTotal.Text = decTotal.ToString("C")

        ElseIf lstSelectedProducts.SelectedItem.ToString() = "Feel the Stress (Print)" Then
            lstSelectedProducts.Items.Remove("Feel the Stress (Print)")
            decSubtotal -= decPrintStress
            lblSubtotal.Text = decSubtotal.ToString("C")
            decTotalTax -= decPrintStress * decTax
            lblTax.Text = decTotalTax.ToString("C")
            ShippingCalculations()
            decTotal -= decPrintStress + decShipping + (decPrintStress * decTax)
            lblTotal.Text = decTotal.ToString("C")
        End If
    End Sub

    Private Sub mnuFileReset_Click(sender As Object, e As EventArgs) Handles mnuFileReset.Click
        lblSubtotal.Text = String.Empty
        decSubtotal = 0
        lblTax.Text = String.Empty
        decTotalTax = 0
        lblShipping.Text = String.Empty
        decShippingTotal = 0
        lblTotal.Text = String.Empty
        decTotal = 0

        lstSelectedProducts.Items.Clear()
    End Sub

    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        MessageBox.Show("This is an application to show how much money you spend on damn books!")
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub


End Class
