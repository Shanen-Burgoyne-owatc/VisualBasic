﻿Public Class AudioBooks
    Private Sub btnAddBook_Click(sender As Object, e As EventArgs) Handles btnAddBook.Click

        If lstAudioBooks.SelectedIndex = 0 Then
            MainForm.lstSelectedProducts.Items.Add("Learn Calculus in One Day (Audio)")
            decSubtotal += decAudioCalculus
        End If

        If lstAudioBooks.SelectedIndex = 1 Then
            MainForm.lstSelectedProducts.Items.Add("The History of Scotland (Audio)")
            decSubtotal += decAudioScotland
        End If

        If lstAudioBooks.SelectedIndex = 2 Then
            MainForm.lstSelectedProducts.Items.Add("The Science of Body Language (Audio)")
            decSubtotal += decAudioBodyLanguage
        End If

        If lstAudioBooks.SelectedIndex = 3 Then
            MainForm.lstSelectedProducts.Items.Add("Relaxation Techniques (Audio)")
            decSubtotal += decAudioRelaxationTech
        End If

        'decShippingTotal = (decShipping * MainForm.lstSelectedProducts.Items.Count())
        MainForm.ShippingCalculations()
        decTotalTax = (decSubtotal * decTax)
        MainForm.lblTax.Text = decTotalTax.ToString("C")
        decTotal = ((decSubtotal + decShippingTotal) + decTotalTax)
        MainForm.lblTotal.Text = decTotal.ToString("C")
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class