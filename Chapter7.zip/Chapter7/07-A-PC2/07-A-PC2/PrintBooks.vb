﻿Public Class PrintBooks
    Private Sub btnAddBook_Click(sender As Object, e As EventArgs) Handles btnAddBook.Click

        If lstPrintBooks.SelectedIndex = 0 Then
            MainForm.lstSelectedProducts.Items.Add("I Did It Your Way (Print)")
            decSubtotal += decPrintYourWay
        End If

        If lstPrintBooks.SelectedIndex = 1 Then
            MainForm.lstSelectedProducts.Items.Add("The History of Scotland (Print)")
            decSubtotal += decPrintScotland
        End If

        If lstPrintBooks.SelectedIndex = 2 Then
            MainForm.lstSelectedProducts.Items.Add("Learn Calculus in One Day (Print)")
            decSubtotal += decPrintCalculus
        End If

        If lstPrintBooks.SelectedIndex = 3 Then
            MainForm.lstSelectedProducts.Items.Add("Feel the Stress (Print)")
            decSubtotal += decPrintStress
        End If
        'decShippingTotal = (decShipping * MainForm.lstSelectedProducts.Items.Count())
        MainForm.ShippingCalculations()
        decTotalTax = (decSubtotal * decTax)
        MainForm.lblTax.Text = decTotalTax.ToString("C")
        decTotal = ((decSubtotal + decShippingTotal) + decTotalTax)
        MainForm.lblTotal.Text = decTotal.ToString("C")
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class