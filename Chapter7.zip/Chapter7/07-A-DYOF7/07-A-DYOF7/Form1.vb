﻿Public Class MainForm
    Private Sub btnLearn_Click(sender As Object, e As EventArgs) Handles btnLearn.Click
        Dim frmMercury As New Mercury
        Dim frmVenus As New Venus
        Dim frmEarth As New Earth
        Dim frmMars As New Mars
        Dim frmJupiter As New Jupiter
        Dim frmSaturn As New Saturn
        Dim frmUranus As New Uranus
        Dim frmNeptune As New Neptune
        Dim frmPluto As New Pluto

        If lstPlanets.SelectedIndex = 0 Then
            frmMercury.ShowDialog()
        End If

        If lstPlanets.SelectedIndex = 1 Then
            frmVenus.ShowDialog()
        End If

        If lstPlanets.SelectedIndex = 2 Then
            frmEarth.ShowDialog()
        End If

        If lstPlanets.SelectedIndex = 3 Then
            frmMars.ShowDialog()
        End If

        If lstPlanets.SelectedIndex = 4 Then
            frmJupiter.ShowDialog()
        End If

        If lstPlanets.SelectedIndex = 5 Then
            frmSaturn.ShowDialog()
        End If

        If lstPlanets.SelectedIndex = 6 Then
            frmUranus.ShowDialog()
        End If

        If lstPlanets.SelectedIndex = 7 Then
            frmNeptune.ShowDialog()
        End If

        If lstPlanets.SelectedIndex = 8 Then
            frmPluto.ShowDialog()
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
