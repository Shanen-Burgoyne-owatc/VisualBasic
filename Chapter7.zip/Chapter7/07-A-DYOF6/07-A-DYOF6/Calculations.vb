﻿Module Calculations

    Public decSubtotal As Decimal = 0
    Public decTotal As Decimal = 0
    Public decSalesTax As Decimal = 0.06D
    Public decTaxTotal As Decimal = 0

End Module
