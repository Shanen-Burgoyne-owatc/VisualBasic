﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.radStreetKing = New System.Windows.Forms.RadioButton()
        Me.RadDictator = New System.Windows.Forms.RadioButton()
        Me.RadThrasher = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.RadAxle3 = New System.Windows.Forms.RadioButton()
        Me.RadAxle2 = New System.Windows.Forms.RadioButton()
        Me.RadAxle1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Rad61 = New System.Windows.Forms.RadioButton()
        Me.Rad58 = New System.Windows.Forms.RadioButton()
        Me.Rad55 = New System.Windows.Forms.RadioButton()
        Me.Rad51 = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.chkAssembly = New System.Windows.Forms.CheckBox()
        Me.chkBoltsKit = New System.Windows.Forms.CheckBox()
        Me.chkRiserPads = New System.Windows.Forms.CheckBox()
        Me.chkBearings = New System.Windows.Forms.CheckBox()
        Me.chkGrip = New System.Windows.Forms.CheckBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblSalesTax = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.radStreetKing)
        Me.GroupBox1.Controls.Add(Me.RadDictator)
        Me.GroupBox1.Controls.Add(Me.RadThrasher)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 55)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(302, 168)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Decks"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(231, 123)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "$50"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(231, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "$45"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(231, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "$60"
        '
        'radStreetKing
        '
        Me.radStreetKing.AutoSize = True
        Me.radStreetKing.Location = New System.Drawing.Point(23, 121)
        Me.radStreetKing.Name = "radStreetKing"
        Me.radStreetKing.Size = New System.Drawing.Size(128, 21)
        Me.radStreetKing.TabIndex = 2
        Me.radStreetKing.Text = "The Street King"
        Me.radStreetKing.UseVisualStyleBackColor = True
        '
        'RadDictator
        '
        Me.RadDictator.AutoSize = True
        Me.RadDictator.Location = New System.Drawing.Point(23, 75)
        Me.RadDictator.Name = "RadDictator"
        Me.RadDictator.Size = New System.Drawing.Size(162, 21)
        Me.RadDictator.TabIndex = 1
        Me.RadDictator.Text = "The Dictator of Grind"
        Me.RadDictator.UseVisualStyleBackColor = True
        '
        'RadThrasher
        '
        Me.RadThrasher.AutoSize = True
        Me.RadThrasher.Checked = True
        Me.RadThrasher.Location = New System.Drawing.Point(23, 37)
        Me.RadThrasher.Name = "RadThrasher"
        Me.RadThrasher.Size = New System.Drawing.Size(163, 21)
        Me.RadThrasher.TabIndex = 0
        Me.RadThrasher.TabStop = True
        Me.RadThrasher.Text = "The Master Thrasher"
        Me.RadThrasher.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.RadAxle3)
        Me.GroupBox2.Controls.Add(Me.RadAxle2)
        Me.GroupBox2.Controls.Add(Me.RadAxle1)
        Me.GroupBox2.Location = New System.Drawing.Point(372, 55)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(259, 168)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Truck Assemblies"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(186, 123)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 17)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "$45"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(186, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(32, 17)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "$40"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(186, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "$35"
        '
        'RadAxle3
        '
        Me.RadAxle3.AutoSize = True
        Me.RadAxle3.Location = New System.Drawing.Point(24, 121)
        Me.RadAxle3.Name = "RadAxle3"
        Me.RadAxle3.Size = New System.Drawing.Size(78, 21)
        Me.RadAxle3.TabIndex = 2
        Me.RadAxle3.Text = "8.5 axle"
        Me.RadAxle3.UseVisualStyleBackColor = True
        '
        'RadAxle2
        '
        Me.RadAxle2.AutoSize = True
        Me.RadAxle2.Location = New System.Drawing.Point(24, 77)
        Me.RadAxle2.Name = "RadAxle2"
        Me.RadAxle2.Size = New System.Drawing.Size(66, 21)
        Me.RadAxle2.TabIndex = 1
        Me.RadAxle2.Text = "8 axle"
        Me.RadAxle2.UseVisualStyleBackColor = True
        '
        'RadAxle1
        '
        Me.RadAxle1.AutoSize = True
        Me.RadAxle1.Checked = True
        Me.RadAxle1.Location = New System.Drawing.Point(24, 36)
        Me.RadAxle1.Name = "RadAxle1"
        Me.RadAxle1.Size = New System.Drawing.Size(86, 21)
        Me.RadAxle1.TabIndex = 0
        Me.RadAxle1.TabStop = True
        Me.RadAxle1.Text = "7.75 axle"
        Me.RadAxle1.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Rad61)
        Me.GroupBox3.Controls.Add(Me.Rad58)
        Me.GroupBox3.Controls.Add(Me.Rad55)
        Me.GroupBox3.Controls.Add(Me.Rad51)
        Me.GroupBox3.Location = New System.Drawing.Point(28, 229)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(201, 202)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Wheel sets"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(146, 162)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 17)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "$28"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(146, 122)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(32, 17)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "$24"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(146, 79)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 17)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "$22"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(146, 43)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 17)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "$20"
        '
        'Rad61
        '
        Me.Rad61.AutoSize = True
        Me.Rad61.Location = New System.Drawing.Point(20, 160)
        Me.Rad61.Name = "Rad61"
        Me.Rad61.Size = New System.Drawing.Size(71, 21)
        Me.Rad61.TabIndex = 3
        Me.Rad61.TabStop = True
        Me.Rad61.Text = "61 mm"
        Me.Rad61.UseVisualStyleBackColor = True
        '
        'Rad58
        '
        Me.Rad58.AutoSize = True
        Me.Rad58.Location = New System.Drawing.Point(20, 120)
        Me.Rad58.Name = "Rad58"
        Me.Rad58.Size = New System.Drawing.Size(71, 21)
        Me.Rad58.TabIndex = 2
        Me.Rad58.TabStop = True
        Me.Rad58.Text = "58 mm"
        Me.Rad58.UseVisualStyleBackColor = True
        '
        'Rad55
        '
        Me.Rad55.AutoSize = True
        Me.Rad55.Location = New System.Drawing.Point(20, 77)
        Me.Rad55.Name = "Rad55"
        Me.Rad55.Size = New System.Drawing.Size(71, 21)
        Me.Rad55.TabIndex = 1
        Me.Rad55.TabStop = True
        Me.Rad55.Text = "55 mm"
        Me.Rad55.UseVisualStyleBackColor = True
        '
        'Rad51
        '
        Me.Rad51.AutoSize = True
        Me.Rad51.Checked = True
        Me.Rad51.Location = New System.Drawing.Point(20, 41)
        Me.Rad51.Name = "Rad51"
        Me.Rad51.Size = New System.Drawing.Size(71, 21)
        Me.Rad51.TabIndex = 0
        Me.Rad51.TabStop = True
        Me.Rad51.Text = "51 mm"
        Me.Rad51.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.Label13)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.chkAssembly)
        Me.GroupBox4.Controls.Add(Me.chkBoltsKit)
        Me.GroupBox4.Controls.Add(Me.chkRiserPads)
        Me.GroupBox4.Controls.Add(Me.chkBearings)
        Me.GroupBox4.Controls.Add(Me.chkGrip)
        Me.GroupBox4.Location = New System.Drawing.Point(265, 229)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(366, 202)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Miscellaneous"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(231, 147)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(32, 17)
        Me.Label15.TabIndex = 10
        Me.Label15.Text = "$10"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(328, 79)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 17)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "$2"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(328, 22)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(24, 17)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "$3"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(128, 75)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(32, 17)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "$30"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(128, 25)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(32, 17)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "$10"
        '
        'chkAssembly
        '
        Me.chkAssembly.AutoSize = True
        Me.chkAssembly.Location = New System.Drawing.Point(107, 146)
        Me.chkAssembly.Name = "chkAssembly"
        Me.chkAssembly.Size = New System.Drawing.Size(90, 21)
        Me.chkAssembly.TabIndex = 4
        Me.chkAssembly.Text = "Assembly"
        Me.chkAssembly.UseVisualStyleBackColor = True
        '
        'chkBoltsKit
        '
        Me.chkBoltsKit.AutoSize = True
        Me.chkBoltsKit.Location = New System.Drawing.Point(190, 21)
        Me.chkBoltsKit.Name = "chkBoltsKit"
        Me.chkBoltsKit.Size = New System.Drawing.Size(124, 21)
        Me.chkBoltsKit.TabIndex = 3
        Me.chkBoltsKit.Text = "Nuts && bolts kit"
        Me.chkBoltsKit.UseVisualStyleBackColor = True
        '
        'chkRiserPads
        '
        Me.chkRiserPads.AutoSize = True
        Me.chkRiserPads.Location = New System.Drawing.Point(190, 75)
        Me.chkRiserPads.Name = "chkRiserPads"
        Me.chkRiserPads.Size = New System.Drawing.Size(98, 21)
        Me.chkRiserPads.TabIndex = 2
        Me.chkRiserPads.Text = "Riser pads"
        Me.chkRiserPads.UseVisualStyleBackColor = True
        '
        'chkBearings
        '
        Me.chkBearings.AutoSize = True
        Me.chkBearings.Location = New System.Drawing.Point(14, 75)
        Me.chkBearings.Name = "chkBearings"
        Me.chkBearings.Size = New System.Drawing.Size(86, 21)
        Me.chkBearings.TabIndex = 1
        Me.chkBearings.Text = "Bearings"
        Me.chkBearings.UseVisualStyleBackColor = True
        '
        'chkGrip
        '
        Me.chkGrip.AutoSize = True
        Me.chkGrip.Location = New System.Drawing.Point(14, 21)
        Me.chkGrip.Name = "chkGrip"
        Me.chkGrip.Size = New System.Drawing.Size(89, 21)
        Me.chkGrip.TabIndex = 0
        Me.chkGrip.Text = "Grip tape"
        Me.chkGrip.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(247, 454)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(64, 17)
        Me.Label16.TabIndex = 4
        Me.Label16.Text = "Subtotal:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(242, 490)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(69, 17)
        Me.Label17.TabIndex = 5
        Me.Label17.Text = "Sales tax:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(259, 527)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(44, 17)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "Total:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(36, 581)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(170, 41)
        Me.btnCalculate.TabIndex = 7
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(245, 581)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(170, 41)
        Me.btnReset.TabIndex = 8
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(461, 581)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(170, 41)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblSubtotal
        '
        Me.lblSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSubtotal.Location = New System.Drawing.Point(372, 453)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(100, 23)
        Me.lblSubtotal.TabIndex = 10
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotal.Location = New System.Drawing.Point(372, 526)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(100, 23)
        Me.lblTotal.TabIndex = 11
        '
        'lblSalesTax
        '
        Me.lblSalesTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalesTax.Location = New System.Drawing.Point(372, 489)
        Me.lblSalesTax.Name = "lblSalesTax"
        Me.lblSalesTax.Size = New System.Drawing.Size(100, 23)
        Me.lblSalesTax.TabIndex = 12
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(672, 645)
        Me.Controls.Add(Me.lblSalesTax)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblSubtotal)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "The Skate Shop"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents radStreetKing As RadioButton
    Friend WithEvents RadDictator As RadioButton
    Friend WithEvents RadThrasher As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents RadAxle3 As RadioButton
    Friend WithEvents RadAxle2 As RadioButton
    Friend WithEvents RadAxle1 As RadioButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Rad61 As RadioButton
    Friend WithEvents Rad58 As RadioButton
    Friend WithEvents Rad55 As RadioButton
    Friend WithEvents Rad51 As RadioButton
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents chkAssembly As CheckBox
    Friend WithEvents chkBoltsKit As CheckBox
    Friend WithEvents chkRiserPads As CheckBox
    Friend WithEvents chkBearings As CheckBox
    Friend WithEvents chkGrip As CheckBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblSalesTax As Label
End Class
