﻿Public Class Form1

    Function CalcDecks() As Decimal
        Dim decDecks As Decimal

        If RadThrasher.Checked = True Then
            decDecks = 60D
        End If

        If RadDictator.Checked = True Then
            decDecks = 45D
        End If

        If radStreetKing.Checked = True Then
            decDecks = 50D
        End If

        Return decDecks
    End Function

    Function CalcTruckAssemblies() As Decimal
        Dim decAssemblies As Decimal

        If RadAxle1.Checked = True Then
            decAssemblies = 35D
        End If

        If RadAxle2.Checked = True Then
            decAssemblies = 40D
        End If

        If RadAxle3.Checked = True Then
            decAssemblies = 45D
        End If

        Return decAssemblies
    End Function

    Function CalcWheels() As Decimal
        Dim decWheels As Decimal

        If Rad51.Checked = True Then
            decWheels = 20D
        End If

        If Rad55.Checked = True Then
            decWheels = 22D
        End If

        If Rad58.Checked = True Then
            decWheels = 24D
        End If

        If Rad61.Checked = True Then
            decWheels = 28D
        End If

        Return decWheels
    End Function

    Function CalcMisc() As Decimal
        Dim decCostofMisc As Decimal = 0D

        If chkAssembly.Checked = True Then
            decCostofMisc += 10D
        End If

        If chkGrip.Checked = True Then
            decCostofMisc += 10D
        End If

        If chkBearings.Checked = True Then
            decCostofMisc += 30D
        End If

        If chkRiserPads.Checked = True Then
            decCostofMisc += 2D
        End If

        If chkBoltsKit.Checked = True Then
            decCostofMisc += 3D
        End If

        Return decCostofMisc
    End Function

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        decSubtotal = CalcDecks() + CalcTruckAssemblies() + CalcWheels() + CalcMisc()
        If chkAssembly.Checked = True Then
            decTaxTotal = decSalesTax * (decSubtotal - 10D)
        ElseIf chkAssembly.Checked = False Then
            decTaxTotal = decSalesTax * decSubtotal
        End If

        decTotal = decSubtotal + decTaxTotal

        lblSubtotal.Text = decSubtotal.ToString("C")
        lblSalesTax.Text = decTaxTotal.ToString("C")
        lblTotal.Text = decTotal.ToString("C")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        RadThrasher.Checked = True
        RadAxle1.Checked = True
        Rad51.Checked = True

        chkAssembly.Checked = False
        chkBearings.Checked = False
        chkBoltsKit.Checked = False
        chkGrip.Checked = False
        chkRiserPads.Checked = False

        lblSalesTax.Text = String.Empty
        lblSubtotal.Text = String.Empty
        lblTotal.Text = String.Empty

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
