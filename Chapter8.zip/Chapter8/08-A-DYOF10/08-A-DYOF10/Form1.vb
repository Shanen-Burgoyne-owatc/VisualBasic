﻿Public Class Form1

    Const intMax_SUBSCRIPT As Integer = 4
    Dim intNumbers(intMax_SUBSCRIPT) As Integer
    Private Sub btnLottery_Click(sender As Object, e As EventArgs) Handles btnLottery.Click
        Dim intCount As Integer
        Dim rand As New Random
        Dim match As Integer = 0
        Dim intUsrNumbers(intMax_SUBSCRIPT) As Integer
        Dim msgString As String = ""
        For intCount = 0 To intMax_SUBSCRIPT
            intNumbers(intCount) = rand.Next(10)
        Next

        lbl1.Text = intNumbers(0).ToString()
        lbl2.Text = intNumbers(1).ToString()
        lbl3.Text = intNumbers(2).ToString()
        lbl4.Text = intNumbers(3).ToString()
        lbl5.Text = intNumbers(4).ToString()

        Try
            intUsrNumbers(0) = CInt(txt1.Text)
            intUsrNumbers(1) = CInt(txt2.Text)
            intUsrNumbers(2) = CInt(txt3.Text)
            intUsrNumbers(3) = CInt(txt4.Text)
            intUsrNumbers(4) = CInt(txt5.Text)
            For intCount = 0 To intMax_SUBSCRIPT
                If intNumbers(intCount) = intUsrNumbers(intCount) Then
                    match += 1
                End If
            Next
            If match = 5 Then
                MessageBox.Show("Grand Winner", "Winner")
            End If
            MessageBox.Show(match & " Numbers Matched with the LOTTO",
            "Matched")
        Catch
            MessageBox.Show("Invalid Input", "ERROR")
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
