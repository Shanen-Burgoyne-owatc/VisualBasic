﻿Option Strict Off
Public Class Form1
    Dim cmpSelection As String
    Public Sub computerChoice()
        Dim rand As New Random
        Dim RPS(2) As String
        RPS(0) = "Rock"
        RPS(1) = "Paper"
        RPS(2) = "Scissor"
        Dim strSelected As String
        picBoxRock.BorderStyle = BorderStyle.None
        picBoxScissors.BorderStyle = BorderStyle.None
        picBoxPaper.BorderStyle = BorderStyle.None
        strSelected = rand.Next(3)
        If strSelected = 0 Then
            picBoxComputer.Image = picBoxRock.Image
        ElseIf strSelected = 1 Then
            picBoxComputer.Image = picBoxPaper.Image
        ElseIf strSelected = 2 Then
            picBoxComputer.Image = picBoxScissors.Image
        End If

        cmpSelection = RPS(strSelected)
        lblWinner.Text = String.Empty
    End Sub



    Private Sub picBoxPaper_Click(sender As Object, e As EventArgs) Handles picBoxPaper.Click
        computerChoice()
        If cmpSelection = "Rock" Then
            lblWinner.Text = "Paper WINS because paper covers rock"
        ElseIf cmpSelection = "Paper" Then
            If (MessageBox.Show("TIE! Would you like to play
                                again?", "TIE",
                MessageBoxButtons.YesNo).Equals(DialogResult.No)) Then
                Me.Close()
            End If
        ElseIf cmpSelection = "Scissor" Then
            lblWinner.Text = "Scissors win becuase scissors cut paper"
        End If
        picBoxPaper.BorderStyle = BorderStyle.FixedSingle
    End Sub

    Private Sub picBoxScissors_Click(sender As Object, e As EventArgs) Handles picBoxScissors.Click
        computerChoice()
        If cmpSelection = "Rock" Then
            lblWinner.Text = "Rock WINS because rock breaks scissors"
        ElseIf cmpSelection = "Paper" Then
            lblWinner.Text = "Scissors win becuase scissors cut paper"
        ElseIf cmpSelection = "Scissor" Then

            If (MessageBox.Show("TIE! Would you like to play
                                again?", "TIE",
                MessageBoxButtons.YesNo).Equals(DialogResult.No)) Then
                Me.Close()
            End If
        End If
        picBoxScissors.BorderStyle = BorderStyle.FixedSingle
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblWinner.Text = String.Empty
        picBoxRock.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub picBoxRock_Click(sender As Object, e As EventArgs) Handles picBoxRock.Click
        computerChoice()
        If cmpSelection = "Rock" Then
            If (MessageBox.Show("TIE! Would you like to play
                                again?", "TIE",
                MessageBoxButtons.YesNo).Equals(DialogResult.No)) Then
                Me.Close()
            End If
        ElseIf cmpSelection = "Paper" Then
            lblWinner.Text = "Computer wins because paper covers rock"
        ElseIf cmpSelection = "Scissor" Then
            lblWinner.Text = "Rock wins because rock breaks scissors"
        End If
        picBoxRock.BorderStyle = BorderStyle.FixedSingle
    End Sub
End Class
