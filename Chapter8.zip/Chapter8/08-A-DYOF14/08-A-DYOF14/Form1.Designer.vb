﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.picBoxRock = New System.Windows.Forms.PictureBox()
        Me.picBoxPaper = New System.Windows.Forms.PictureBox()
        Me.picBoxScissors = New System.Windows.Forms.PictureBox()
        Me.lblWinner = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.picBoxComputer = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.picBoxRock, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBoxPaper, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBoxScissors, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBoxComputer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBoxRock
        '
        Me.picBoxRock.BackgroundImage = CType(resources.GetObject("picBoxRock.BackgroundImage"), System.Drawing.Image)
        Me.picBoxRock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBoxRock.Location = New System.Drawing.Point(12, 33)
        Me.picBoxRock.Name = "picBoxRock"
        Me.picBoxRock.Size = New System.Drawing.Size(171, 172)
        Me.picBoxRock.TabIndex = 4
        Me.picBoxRock.TabStop = False
        '
        'picBoxPaper
        '
        Me.picBoxPaper.BackgroundImage = CType(resources.GetObject("picBoxPaper.BackgroundImage"), System.Drawing.Image)
        Me.picBoxPaper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBoxPaper.Location = New System.Drawing.Point(236, 33)
        Me.picBoxPaper.Name = "picBoxPaper"
        Me.picBoxPaper.Size = New System.Drawing.Size(172, 173)
        Me.picBoxPaper.TabIndex = 5
        Me.picBoxPaper.TabStop = False
        '
        'picBoxScissors
        '
        Me.picBoxScissors.BackgroundImage = CType(resources.GetObject("picBoxScissors.BackgroundImage"), System.Drawing.Image)
        Me.picBoxScissors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBoxScissors.Location = New System.Drawing.Point(455, 33)
        Me.picBoxScissors.Name = "picBoxScissors"
        Me.picBoxScissors.Size = New System.Drawing.Size(172, 173)
        Me.picBoxScissors.TabIndex = 6
        Me.picBoxScissors.TabStop = False
        '
        'lblWinner
        '
        Me.lblWinner.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWinner.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWinner.Location = New System.Drawing.Point(39, 369)
        Me.lblWinner.Name = "lblWinner"
        Me.lblWinner.Size = New System.Drawing.Size(555, 94)
        Me.lblWinner.TabIndex = 7
        Me.lblWinner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(101, 498)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(196, 80)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(354, 498)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(196, 80)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'picBoxComputer
        '
        Me.picBoxComputer.Location = New System.Drawing.Point(307, 212)
        Me.picBoxComputer.Name = "picBoxComputer"
        Me.picBoxComputer.Size = New System.Drawing.Size(172, 139)
        Me.picBoxComputer.TabIndex = 10
        Me.picBoxComputer.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(22, 292)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(262, 32)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Computer's Choice:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(657, 602)
        Me.Controls.Add(Me.picBoxComputer)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblWinner)
        Me.Controls.Add(Me.picBoxScissors)
        Me.Controls.Add(Me.picBoxPaper)
        Me.Controls.Add(Me.picBoxRock)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Rock, Paper, Scissors"
        CType(Me.picBoxRock, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBoxPaper, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBoxScissors, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBoxComputer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picBoxRock As PictureBox
    Friend WithEvents picBoxPaper As PictureBox
    Friend WithEvents picBoxScissors As PictureBox
    Friend WithEvents lblWinner As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents picBoxComputer As PictureBox
    Friend WithEvents Label1 As Label
End Class
