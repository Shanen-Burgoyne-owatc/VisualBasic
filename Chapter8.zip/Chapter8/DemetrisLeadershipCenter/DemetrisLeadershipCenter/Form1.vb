﻿Public Class Form1
    ' This application displays a sales report for the Demetris
    ' Leadership Center.

    ' Class-level declarations
    Const intMAX_SUBSCRIPT As Integer = 4
    Dim strProdNames(intMAX_SUBSCRIPT) As String
    Dim strDesc(intMAX_SUBSCRIPT) As String
    Dim intProdNames(intMAX_SUBSCRIPT) As Integer
    Dim decPrices(intMAX_SUBSCRIPT) As Decimal
    Dim intUnitSold(intMAX_SUBSCRIPT) As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initialize the arrays with product data.
        InitArrays()
    End Sub

    Private Sub InitArrays()
        ' Initialize the arrays.
        ' First product
        strProdNames(0) = "Six Steps to Leadership"
        strDesc(0) = "Book"
        intProdNames(0) = 914
        decPrices(0) = 12.95D

        ' Second product
        strProdNames(1) = "Six Steps to Leadership"
        strDesc(1) = "CD"
        intProdNames(1) = 915
        decPrices(1) = 14.95D

        ' Third Product
        strProdNames(2) = "The Road to Excellence"
        strDesc(2) = "Video"
        intProdNames(2) = 916
        decPrices(2) = 18.95D

        ' Fourth product
        strProdNames(3) = "Seven Lessons of Quality"
        strDesc(3) = "Book"
        intProdNames(3) = 917
        decPrices(3) = 16.95D

        'Fifth product
        strProdNames(4) = "Seven Lessons of Quality"
        strDesc(4) = "CD"
        intProdNames(4) = 918
        decPrices(4) = 21.95D
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        ' Close the form
        Me.Close()
    End Sub

    Private Sub mnuReportData_Click(sender As Object, e As EventArgs) Handles mnuReportData.Click
        Dim intCount As Integer = 0

        Do While intCount <= intMAX_SUBSCRIPT
            Try
                ' Get the units sold for a product.
                intUnitSold(intCount) = CInt(
                    InputBox("Enter units sold of product number " &
                            intProdNames(intCount)))

                ' Increment intCount
                intCount += 1
            Catch
                ' Error Message for invalid input.
                MessageBox.Show("Enter a valid integer.")
            End Try
        Loop
    End Sub

    Private Sub mnuReportDisplay_Click(sender As Object, e As EventArgs) Handles mnuReportDisplay.Click
        ' Calculates and displays the revenue for each
        ' product and the total revenue.
        Dim intCount As Integer
        Dim decRevenue As Decimal
        Dim decTotalRevenue As Decimal

        ' Display the sales report header.
        lstSalesData.Items.Add("SALES REPORT")
        lstSalesData.Items.Add("-------------------")

        ' Display sales data for each product
        For intCount = 0 To intMAX_SUBSCRIPT

            ' Calculate product revenue.
            decRevenue = intUnitSold(intCount) * decPrices(intCount)

            ' Display the product data.
            lstSalesData.Items.Add("Product Number: " &
                               intProdNames(intCount))
            lstSalesData.Items.Add("Name: " &
                               strProdNames(intCount))
            lstSalesData.Items.Add("Description: " &
                               strDesc(intCount))
            lstSalesData.Items.Add("Unit Price: " &
                               decPrices(intCount).ToString("C"))
            lstSalesData.Items.Add("Units Sold: " &
                               intUnitSold(intCount).ToString("C"))
            lstSalesData.Items.Add("Product Revenue: " &
                               decRevenue.ToString("C"))
            lstSalesData.Items.Add("")

            ' Accumulate revenue
            decTotalRevenue = decTotalRevenue + decRevenue
        Next

        ' Display total revenue.
        lblTotalRevenue.Text = decTotalRevenue.ToString("C")
    End Sub

    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        ' Display an About box.
        MessageBox.Show("Displays a sales report for DLC.", "About")
    End Sub
End Class
