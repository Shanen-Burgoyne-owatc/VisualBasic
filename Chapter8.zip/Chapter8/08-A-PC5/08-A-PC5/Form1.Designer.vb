﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtDigit1 = New System.Windows.Forms.TextBox()
        Me.txtDigit2 = New System.Windows.Forms.TextBox()
        Me.txtDigit3 = New System.Windows.Forms.TextBox()
        Me.txtDigit4 = New System.Windows.Forms.TextBox()
        Me.txtDigit5 = New System.Windows.Forms.TextBox()
        Me.txtDigit6 = New System.Windows.Forms.TextBox()
        Me.txtDigit7 = New System.Windows.Forms.TextBox()
        Me.btnVerify = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtDigit7)
        Me.GroupBox1.Controls.Add(Me.txtDigit6)
        Me.GroupBox1.Controls.Add(Me.txtDigit5)
        Me.GroupBox1.Controls.Add(Me.txtDigit4)
        Me.GroupBox1.Controls.Add(Me.txtDigit3)
        Me.GroupBox1.Controls.Add(Me.txtDigit2)
        Me.GroupBox1.Controls.Add(Me.txtDigit1)
        Me.GroupBox1.Location = New System.Drawing.Point(25, 25)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(566, 176)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Enter the PIN"
        '
        'txtDigit1
        '
        Me.txtDigit1.Location = New System.Drawing.Point(21, 72)
        Me.txtDigit1.Multiline = True
        Me.txtDigit1.Name = "txtDigit1"
        Me.txtDigit1.Size = New System.Drawing.Size(52, 41)
        Me.txtDigit1.TabIndex = 0
        '
        'txtDigit2
        '
        Me.txtDigit2.Location = New System.Drawing.Point(96, 72)
        Me.txtDigit2.Multiline = True
        Me.txtDigit2.Name = "txtDigit2"
        Me.txtDigit2.Size = New System.Drawing.Size(52, 41)
        Me.txtDigit2.TabIndex = 1
        '
        'txtDigit3
        '
        Me.txtDigit3.Location = New System.Drawing.Point(170, 72)
        Me.txtDigit3.Multiline = True
        Me.txtDigit3.Name = "txtDigit3"
        Me.txtDigit3.Size = New System.Drawing.Size(52, 41)
        Me.txtDigit3.TabIndex = 2
        '
        'txtDigit4
        '
        Me.txtDigit4.Location = New System.Drawing.Point(242, 72)
        Me.txtDigit4.Multiline = True
        Me.txtDigit4.Name = "txtDigit4"
        Me.txtDigit4.Size = New System.Drawing.Size(52, 41)
        Me.txtDigit4.TabIndex = 3
        '
        'txtDigit5
        '
        Me.txtDigit5.Location = New System.Drawing.Point(317, 72)
        Me.txtDigit5.Multiline = True
        Me.txtDigit5.Name = "txtDigit5"
        Me.txtDigit5.Size = New System.Drawing.Size(52, 41)
        Me.txtDigit5.TabIndex = 4
        '
        'txtDigit6
        '
        Me.txtDigit6.Location = New System.Drawing.Point(390, 72)
        Me.txtDigit6.Multiline = True
        Me.txtDigit6.Name = "txtDigit6"
        Me.txtDigit6.Size = New System.Drawing.Size(52, 41)
        Me.txtDigit6.TabIndex = 5
        '
        'txtDigit7
        '
        Me.txtDigit7.Location = New System.Drawing.Point(471, 72)
        Me.txtDigit7.Multiline = True
        Me.txtDigit7.Name = "txtDigit7"
        Me.txtDigit7.Size = New System.Drawing.Size(52, 41)
        Me.txtDigit7.TabIndex = 6
        '
        'btnVerify
        '
        Me.btnVerify.Location = New System.Drawing.Point(25, 218)
        Me.btnVerify.Name = "btnVerify"
        Me.btnVerify.Size = New System.Drawing.Size(160, 51)
        Me.btnVerify.TabIndex = 1
        Me.btnVerify.Text = "Verify"
        Me.btnVerify.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(225, 218)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(160, 51)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(431, 218)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(160, 51)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(624, 292)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnVerify)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "PIN Verifier"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtDigit7 As TextBox
    Friend WithEvents txtDigit6 As TextBox
    Friend WithEvents txtDigit5 As TextBox
    Friend WithEvents txtDigit4 As TextBox
    Friend WithEvents txtDigit3 As TextBox
    Friend WithEvents txtDigit2 As TextBox
    Friend WithEvents txtDigit1 As TextBox
    Friend WithEvents btnVerify As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
