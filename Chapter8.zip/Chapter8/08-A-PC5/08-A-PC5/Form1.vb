﻿Public Class Form1
    Private Sub btnVerify_Click(sender As Object, e As EventArgs) Handles btnVerify.Click
        Dim intMinimum() As Integer = {7, 5, 0, 0, 6, 3, 4}
        Dim intMaximum() As Integer = {9, 7, 4, 9, 9, 6, 8}
        Dim strInput(6) As Integer
        Dim intCount As Integer = 0
        Dim success As Integer = 0

        Try
            strInput(0) = CInt(txtDigit1.Text)
            strInput(1) = CInt(txtDigit2.Text)
            strInput(2) = CInt(txtDigit3.Text)
            strInput(3) = CInt(txtDigit4.Text)
            strInput(4) = CInt(txtDigit5.Text)
            strInput(5) = CInt(txtDigit6.Text)
            strInput(6) = CInt(txtDigit7.Text)

            For intCount = 0 To (strInput.Length - 1)
                If strInput(intCount) >= intMinimum(intCount) And
                    strInput(intCount) <= intMaximum(intCount) Then

                    success = success + 1
                End If
            Next
            If success = 7 Then
                MessageBox.Show("PIN Verified", "Sucess",
MessageBoxButtons.OK,
MessageBoxIcon.Information)
            Else
                MessageBox.Show("Invalid PIN", "Fail",
MessageBoxButtons.OK,
MessageBoxIcon.Information)
            End If
        Catch
            MessageBox.Show("Input should be numeric and not NULL",
"Error", MessageBoxButtons.OK,
MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtDigit1.Text = String.Empty
        txtDigit2.Text = String.Empty
        txtDigit3.Text = String.Empty
        txtDigit4.Text = String.Empty
        txtDigit5.Text = String.Empty
        txtDigit6.Text = String.Empty
        txtDigit7.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
