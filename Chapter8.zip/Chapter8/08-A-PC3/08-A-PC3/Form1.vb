﻿Option Strict On
Public Class Form1
    Dim strNouns() As String = {"Martian", "baby", "skunk", "computer",
        "mosquito"}

    Dim strVerbs() As String = {"ran", "fell", "flew", "jumped", "walked"}

    Dim strArticles() As String = {"A", "The", "One", "Some", "Another"}

    Dim strAdjectives() As String = {"huge", "shiny", "unusual", "silly",
        "bright"}

    Dim strPrepositions() As String = {"around", "through", "under", "over",
        "by"}
    Private Sub btnNextSentence_Click(sender As Object, e As EventArgs) Handles btnNextSentence.Click
        Dim rndVal As New Random
        Dim strSentence As String = ""
        Dim index As Integer

        index = rndVal.Next(0, strArticles.Length)
        strSentence &= strArticles(index) & " "

        index = rndVal.Next(0, strAdjectives.Length)
        strSentence &= strAdjectives(index) & " "

        index = rndVal.Next(0, strNouns.Length)
        strSentence &= strNouns(index) & " "

        index = rndVal.Next(0, strVerbs.Length)
        strSentence &= strVerbs(index) & " "

        index = rndVal.Next(0, strPrepositions.Length)
        strSentence &= strPrepositions(index) & " "

        index = rndVal.Next(0, strArticles.Length)
        strSentence &= strArticles(index).ToLower() & " "

        index = rndVal.Next(0, strAdjectives.Length)
        strSentence &= strAdjectives(index) & " "

        index = rndVal.Next(0, strNouns.Length)
        strSentence &= strNouns(index) & "."

        lstSentences.Items.Add(strSentence)
    End Sub

    Private Sub btnClearSentence_Click(sender As Object, e As EventArgs) Handles btnClearSentence.Click
        lstSentences.Items.Clear()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
