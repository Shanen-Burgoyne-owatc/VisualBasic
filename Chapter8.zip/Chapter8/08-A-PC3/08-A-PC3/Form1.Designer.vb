﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstSentences = New System.Windows.Forms.ListBox()
        Me.btnNextSentence = New System.Windows.Forms.Button()
        Me.btnClearSentence = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstSentences
        '
        Me.lstSentences.FormattingEnabled = True
        Me.lstSentences.ItemHeight = 16
        Me.lstSentences.Location = New System.Drawing.Point(23, 27)
        Me.lstSentences.Name = "lstSentences"
        Me.lstSentences.Size = New System.Drawing.Size(728, 244)
        Me.lstSentences.TabIndex = 0
        '
        'btnNextSentence
        '
        Me.btnNextSentence.Location = New System.Drawing.Point(23, 313)
        Me.btnNextSentence.Name = "btnNextSentence"
        Me.btnNextSentence.Size = New System.Drawing.Size(190, 50)
        Me.btnNextSentence.TabIndex = 1
        Me.btnNextSentence.Text = "Next Sentence"
        Me.btnNextSentence.UseVisualStyleBackColor = True
        '
        'btnClearSentence
        '
        Me.btnClearSentence.Location = New System.Drawing.Point(296, 313)
        Me.btnClearSentence.Name = "btnClearSentence"
        Me.btnClearSentence.Size = New System.Drawing.Size(190, 50)
        Me.btnClearSentence.TabIndex = 2
        Me.btnClearSentence.Text = "Clear Sentences"
        Me.btnClearSentence.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(561, 313)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(190, 50)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 391)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClearSentence)
        Me.Controls.Add(Me.btnNextSentence)
        Me.Controls.Add(Me.lstSentences)
        Me.Name = "Form1"
        Me.Text = "RandomSentences"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lstSentences As ListBox
    Friend WithEvents btnNextSentence As Button
    Friend WithEvents btnClearSentence As Button
    Friend WithEvents btnExit As Button
End Class
