﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txt20 = New System.Windows.Forms.TextBox()
        Me.txt19 = New System.Windows.Forms.TextBox()
        Me.txt18 = New System.Windows.Forms.TextBox()
        Me.txt17 = New System.Windows.Forms.TextBox()
        Me.txt16 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txt15 = New System.Windows.Forms.TextBox()
        Me.txt14 = New System.Windows.Forms.TextBox()
        Me.txt13 = New System.Windows.Forms.TextBox()
        Me.txt12 = New System.Windows.Forms.TextBox()
        Me.txt11 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txt10 = New System.Windows.Forms.TextBox()
        Me.txt9 = New System.Windows.Forms.TextBox()
        Me.txt8 = New System.Windows.Forms.TextBox()
        Me.txt7 = New System.Windows.Forms.TextBox()
        Me.txt6 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt5 = New System.Windows.Forms.TextBox()
        Me.txt4 = New System.Windows.Forms.TextBox()
        Me.txt3 = New System.Windows.Forms.TextBox()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnScore = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txt20)
        Me.GroupBox1.Controls.Add(Me.txt19)
        Me.GroupBox1.Controls.Add(Me.txt18)
        Me.GroupBox1.Controls.Add(Me.txt17)
        Me.GroupBox1.Controls.Add(Me.txt16)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.txt15)
        Me.GroupBox1.Controls.Add(Me.txt14)
        Me.GroupBox1.Controls.Add(Me.txt13)
        Me.GroupBox1.Controls.Add(Me.txt12)
        Me.GroupBox1.Controls.Add(Me.txt11)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.txt10)
        Me.GroupBox1.Controls.Add(Me.txt9)
        Me.GroupBox1.Controls.Add(Me.txt8)
        Me.GroupBox1.Controls.Add(Me.txt7)
        Me.GroupBox1.Controls.Add(Me.txt6)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txt5)
        Me.GroupBox1.Controls.Add(Me.txt4)
        Me.GroupBox1.Controls.Add(Me.txt3)
        Me.GroupBox1.Controls.Add(Me.txt2)
        Me.GroupBox1.Controls.Add(Me.txt1)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(31, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(693, 287)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Answers"
        '
        'txt20
        '
        Me.txt20.Location = New System.Drawing.Point(587, 235)
        Me.txt20.Multiline = True
        Me.txt20.Name = "txt20"
        Me.txt20.Size = New System.Drawing.Size(85, 28)
        Me.txt20.TabIndex = 39
        '
        'txt19
        '
        Me.txt19.Location = New System.Drawing.Point(587, 181)
        Me.txt19.Multiline = True
        Me.txt19.Name = "txt19"
        Me.txt19.Size = New System.Drawing.Size(85, 28)
        Me.txt19.TabIndex = 38
        '
        'txt18
        '
        Me.txt18.Location = New System.Drawing.Point(587, 131)
        Me.txt18.Multiline = True
        Me.txt18.Name = "txt18"
        Me.txt18.Size = New System.Drawing.Size(85, 28)
        Me.txt18.TabIndex = 37
        '
        'txt17
        '
        Me.txt17.Location = New System.Drawing.Point(587, 84)
        Me.txt17.Multiline = True
        Me.txt17.Name = "txt17"
        Me.txt17.Size = New System.Drawing.Size(85, 28)
        Me.txt17.TabIndex = 36
        '
        'txt16
        '
        Me.txt16.Location = New System.Drawing.Point(587, 40)
        Me.txt16.Multiline = True
        Me.txt16.Name = "txt16"
        Me.txt16.Size = New System.Drawing.Size(85, 28)
        Me.txt16.TabIndex = 35
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(550, 238)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(28, 17)
        Me.Label16.TabIndex = 34
        Me.Label16.Text = "20."
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(550, 184)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(28, 17)
        Me.Label17.TabIndex = 33
        Me.Label17.Text = "19."
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(550, 134)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(28, 17)
        Me.Label18.TabIndex = 32
        Me.Label18.Text = "18."
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(550, 87)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(28, 17)
        Me.Label19.TabIndex = 31
        Me.Label19.Text = "17."
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(550, 43)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(28, 17)
        Me.Label20.TabIndex = 30
        Me.Label20.Text = "16."
        '
        'txt15
        '
        Me.txt15.Location = New System.Drawing.Point(423, 235)
        Me.txt15.Multiline = True
        Me.txt15.Name = "txt15"
        Me.txt15.Size = New System.Drawing.Size(85, 28)
        Me.txt15.TabIndex = 29
        '
        'txt14
        '
        Me.txt14.Location = New System.Drawing.Point(423, 181)
        Me.txt14.Multiline = True
        Me.txt14.Name = "txt14"
        Me.txt14.Size = New System.Drawing.Size(85, 28)
        Me.txt14.TabIndex = 28
        '
        'txt13
        '
        Me.txt13.Location = New System.Drawing.Point(423, 131)
        Me.txt13.Multiline = True
        Me.txt13.Name = "txt13"
        Me.txt13.Size = New System.Drawing.Size(85, 28)
        Me.txt13.TabIndex = 27
        '
        'txt12
        '
        Me.txt12.Location = New System.Drawing.Point(423, 84)
        Me.txt12.Multiline = True
        Me.txt12.Name = "txt12"
        Me.txt12.Size = New System.Drawing.Size(85, 28)
        Me.txt12.TabIndex = 26
        '
        'txt11
        '
        Me.txt11.Location = New System.Drawing.Point(423, 40)
        Me.txt11.Multiline = True
        Me.txt11.Name = "txt11"
        Me.txt11.Size = New System.Drawing.Size(85, 28)
        Me.txt11.TabIndex = 25
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(386, 238)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 17)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "15."
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(386, 184)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(28, 17)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "14."
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(386, 134)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(28, 17)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "13."
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(386, 87)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(28, 17)
        Me.Label14.TabIndex = 21
        Me.Label14.Text = "12."
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(386, 43)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(28, 17)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "11."
        '
        'txt10
        '
        Me.txt10.Location = New System.Drawing.Point(247, 235)
        Me.txt10.Multiline = True
        Me.txt10.Name = "txt10"
        Me.txt10.Size = New System.Drawing.Size(85, 28)
        Me.txt10.TabIndex = 19
        '
        'txt9
        '
        Me.txt9.Location = New System.Drawing.Point(247, 181)
        Me.txt9.Multiline = True
        Me.txt9.Name = "txt9"
        Me.txt9.Size = New System.Drawing.Size(85, 28)
        Me.txt9.TabIndex = 18
        '
        'txt8
        '
        Me.txt8.Location = New System.Drawing.Point(247, 131)
        Me.txt8.Multiline = True
        Me.txt8.Name = "txt8"
        Me.txt8.Size = New System.Drawing.Size(85, 28)
        Me.txt8.TabIndex = 17
        '
        'txt7
        '
        Me.txt7.Location = New System.Drawing.Point(247, 84)
        Me.txt7.Multiline = True
        Me.txt7.Name = "txt7"
        Me.txt7.Size = New System.Drawing.Size(85, 28)
        Me.txt7.TabIndex = 16
        '
        'txt6
        '
        Me.txt6.Location = New System.Drawing.Point(247, 40)
        Me.txt6.Multiline = True
        Me.txt6.Name = "txt6"
        Me.txt6.Size = New System.Drawing.Size(85, 28)
        Me.txt6.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(210, 238)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 17)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "10."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(210, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(20, 17)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "9."
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(210, 134)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(20, 17)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "8."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(210, 87)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(20, 17)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "7."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(210, 43)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(20, 17)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "6."
        '
        'txt5
        '
        Me.txt5.Location = New System.Drawing.Point(62, 235)
        Me.txt5.Multiline = True
        Me.txt5.Name = "txt5"
        Me.txt5.Size = New System.Drawing.Size(85, 28)
        Me.txt5.TabIndex = 9
        '
        'txt4
        '
        Me.txt4.Location = New System.Drawing.Point(62, 181)
        Me.txt4.Multiline = True
        Me.txt4.Name = "txt4"
        Me.txt4.Size = New System.Drawing.Size(85, 28)
        Me.txt4.TabIndex = 8
        '
        'txt3
        '
        Me.txt3.Location = New System.Drawing.Point(62, 131)
        Me.txt3.Multiline = True
        Me.txt3.Name = "txt3"
        Me.txt3.Size = New System.Drawing.Size(85, 28)
        Me.txt3.TabIndex = 7
        '
        'txt2
        '
        Me.txt2.Location = New System.Drawing.Point(62, 84)
        Me.txt2.Multiline = True
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(85, 28)
        Me.txt2.TabIndex = 6
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(62, 40)
        Me.txt1.Multiline = True
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(85, 28)
        Me.txt1.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 238)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(20, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "5."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 184)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(20, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "4."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(25, 134)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(20, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "3."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "2."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(20, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "1."
        '
        'btnScore
        '
        Me.btnScore.Location = New System.Drawing.Point(91, 359)
        Me.btnScore.Name = "btnScore"
        Me.btnScore.Size = New System.Drawing.Size(153, 50)
        Me.btnScore.TabIndex = 1
        Me.btnScore.Text = "&Score Exam"
        Me.btnScore.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(312, 359)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(153, 50)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "C&lear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(532, 359)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(153, 50)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(755, 450)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnScore)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txt20 As TextBox
    Friend WithEvents txt19 As TextBox
    Friend WithEvents txt18 As TextBox
    Friend WithEvents txt17 As TextBox
    Friend WithEvents txt16 As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents txt15 As TextBox
    Friend WithEvents txt14 As TextBox
    Friend WithEvents txt13 As TextBox
    Friend WithEvents txt12 As TextBox
    Friend WithEvents txt11 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents txt10 As TextBox
    Friend WithEvents txt9 As TextBox
    Friend WithEvents txt8 As TextBox
    Friend WithEvents txt7 As TextBox
    Friend WithEvents txt6 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txt5 As TextBox
    Friend WithEvents txt4 As TextBox
    Friend WithEvents txt3 As TextBox
    Friend WithEvents txt2 As TextBox
    Friend WithEvents txt1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnScore As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
