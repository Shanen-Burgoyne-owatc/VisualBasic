﻿
Public Class Form1
    Public Property Result As Object

    Private Sub btnScore_Click(sender As Object, e As EventArgs) Handles btnScore.Click
        Dim strGrades() As String = {"B", "D", "A", "A", "C",
            "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C",
            "C", "B", "D", "A"}
        Dim dtlResult(19) As Boolean
        Dim intCorrect As Integer = 0
        Dim validInput As Integer = 0
        frmResult.lstResult.Items.Clear()
        Dim intCount As Integer = 0
        Dim strInput(19) As String
        strInput(0) = txt1.Text
        strInput(1) = txt2.Text
        strInput(2) = txt3.Text
        strInput(3) = txt4.Text
        strInput(4) = txt5.Text
        strInput(5) = txt6.Text
        strInput(6) = txt7.Text
        strInput(7) = txt8.Text
        strInput(8) = txt9.Text
        strInput(9) = txt10.Text
        strInput(10) = txt11.Text
        strInput(11) = txt12.Text
        strInput(12) = txt13.Text
        strInput(13) = txt14.Text
        strInput(14) = txt15.Text
        strInput(15) = txt16.Text
        strInput(16) = txt17.Text
        strInput(17) = txt18.Text
        strInput(18) = txt19.Text
        strInput(19) = txt20.Text
        Try
            For intCount = 0 To (strGrades.Length - 1)
                If strInput(intCount).ToUpper() = "A" Or
                        strInput(intCount).ToUpper() = "B" Or
                        strInput(intCount).ToUpper() = "C" Or
                        strInput(intCount).ToUpper() = "D" Then
                    If strGrades(intCount) =
                            strInput(intCount).ToUpper() Then
                        intCorrect += 1
                        dtlResult(intCount) = True
                    End If
                    validInput = validInput + 1
                End If
            Next intCount
        Catch

        End Try

        If validInput = 20 Then
            Dim frmResult As New frmResult
            frmResult.lstResult.Items.Clear()
            frmResult.lstResult.Items.Add("----------------------------------
----------------")
            frmResult.lstResult.Items.Add("Driver's License Exam
Results")
            frmResult.lstResult.Items.add("----------------------------------
-----------------")
            For intCount = 0 To (19)
                If (dtlResult(intCount) = True) Then
                    frmResult.lstResult.Items.Add(intCount + 1 &
                    " Correct" & "               Answer: " & strGrades(intCount))
                Else
                    frmResult.lstResult.Items.Add(intCount + 1 &
                    "Wrong" & "        Answer: " & strGrades(intCount))
                End If
            Next intCount
            frmResult.lstResult.Items.Add("-----------------------------------
-------------------")
            frmResult.lstResult.Items.Add(" Total :" & intCorrect & " /20")

            If (intCorrect >= 15) Then
                frmResult.lstResult.Items.Add("Your Result: " & "
PASS")
            Else
                frmResult.lstResult.Items.Add("Your Result: " & "
FAIL")
            End If
            frmResult.ShowDialog()
        Else

            MessageBox.Show("Input Should be A, B, C, or D",
"Input Validation")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txt1.Text = String.Empty
        txt2.Text = String.Empty
        txt3.Text = String.Empty
        txt4.Text = String.Empty
        txt5.Text = String.Empty
        txt6.Text = String.Empty
        txt7.Text = String.Empty
        txt8.Text = String.Empty
        txt9.Text = String.Empty
        txt10.Text = String.Empty
        txt11.Text = String.Empty
        txt12.Text = String.Empty
        txt13.Text = String.Empty
        txt14.Text = String.Empty
        txt15.Text = String.Empty
        txt16.Text = String.Empty
        txt17.Text = String.Empty
        txt18.Text = String.Empty
        txt19.Text = String.Empty
        txt20.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
