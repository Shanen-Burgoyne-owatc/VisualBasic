﻿Public Class Form1

    Dim strPeople(6) As String
    Dim strPhoneNumbers(6) As String

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim name As String
        Dim intCount As Integer
        Dim Found As Boolean = False
        Dim fmtStr As String = "{0, -15}{1, -10}"

        lstPhoneNo.Items.Clear()

        Try
            name = CStr(txtName.Text)
            For intCount = 0 To 6
                If strPeople(intCount).ToUpper.Contains((name.ToUpper)) Then
                    lstPhoneNo.Items.Add(String.Format(fmtStr,
                    strPeople(intCount), strPhoneNumbers(intCount)))
                    Found = True
                End If
            Next
            If Not Found Then
                MessageBox.Show("Person is Not Found", "NOT FOUND",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        strPeople(0) = "Mommy"
        strPeople(1) = "Daddy"
        strPeople(2) = "Mikela Mitchell"
        strPeople(3) = "Kyle Oleson"
        strPeople(4) = "Gary Gray"
        strPeople(5) = "Jose Cruz"
        strPeople(6) = "Darlene Gray"

        strPhoneNumbers(0) = "208-431-6281"
        strPhoneNumbers(1) = "208-431-0509"
        strPhoneNumbers(2) = "520-270-9316"
        strPhoneNumbers(3) = "801-644-3518"
        strPhoneNumbers(4) = "208-251-1825"
        strPhoneNumbers(5) = "208-260-1325"
        strPhoneNumbers(6) = "208-241-9863"
    End Sub
End Class
